<?php
/**
 * Database Features Integration
 * Functions to utilize database views, triggers, and stored procedures
 */

require_once __DIR__ . '/../database/db_connect.php';

/**
 * Get clubs with membership counts using the view
 * @return array Array of clubs with membership details
 */
function getClubsWithMembership() {
    $conn = getDBConnection();
    
    $result = $conn->query("SELECT * FROM ClubMembershipView ORDER BY club_name");
    
    $clubs = [];
    while ($row = $result->fetch_assoc()) {
        $clubs[] = $row;
    }
    
    return $clubs;
}

/**
 * Get upcoming events using the view
 * @param int $limit Limit number of events returned
 * @return array Array of upcoming events
 */
function getUpcomingEventsFromView($limit = 10) {
    $conn = getDBConnection();
    
    $result = $conn->query("SELECT * FROM UpcomingEventsView ORDER BY event_date LIMIT " . (int)$limit);
    
    $events = [];
    while ($row = $result->fetch_assoc()) {
        $events[] = $row;
    }
    
    return $events;
}

/**
 * Get user activity statistics using the view
 * @param int $userId User ID
 * @return array|null User activity data or null if user not found
 */
function getUserActivityStats($userId) {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("SELECT * FROM UserActivityView WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return null;
    }
    
    return $result->fetch_assoc();
}

/**
 * Get event summary for a club using the view
 * @param int $clubId Club ID
 * @return array|null Club event summary or null if club not found
 */
function getClubEventSummary($clubId) {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("SELECT * FROM ClubEventSummaryView WHERE club_id = ?");
    $stmt->bind_param("i", $clubId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return null;
    }
    
    return $result->fetch_assoc();
}

/**
 * Request to join a club using the stored procedure
 * @param int $userId User ID
 * @param int $clubId Club ID
 * @param bool $isDirectJoin Whether to directly add user or create a request
 * @return array Result with success status and message
 */
function joinClubProcedure($userId, $clubId, $isDirectJoin = false) {
    $conn = getDBConnection();
    
    // Initialize output parameters
    $conn->query("SET @success = 0");
    $conn->query("SET @message = ''");
    
    // Call the stored procedure
    $stmt = $conn->prepare("CALL JoinClub(?, ?, ?, @success, @message)");
    $intIsDirectJoin = $isDirectJoin ? 1 : 0;
    $stmt->bind_param("iii", $userId, $clubId, $intIsDirectJoin);
    $stmt->execute();
    
    // Get output parameters
    $result = $conn->query("SELECT @success as success, @message as message");
    $output = $result->fetch_assoc();
    
    return [
        'success' => (bool)$output['success'],
        'message' => $output['message']
    ];
}

/**
 * Process a membership request using the stored procedure
 * @param int $requestId Request ID
 * @param int $adminId Admin user ID processing the request
 * @param string $status New status ('approved' or 'rejected')
 * @return array Result with success status and message
 */
function processMembershipRequestProcedure($requestId, $adminId, $status) {
    $conn = getDBConnection();
    
    // Validate status
    if (!in_array($status, ['approved', 'rejected'])) {
        return [
            'success' => false,
            'message' => 'Invalid status. Must be "approved" or "rejected"'
        ];
    }
    
    // Initialize output parameters
    $conn->query("SET @success = 0");
    $conn->query("SET @message = ''");
    
    // Call the stored procedure
    $stmt = $conn->prepare("CALL ProcessMembershipRequest(?, ?, ?, @success, @message)");
    $stmt->bind_param("iis", $requestId, $adminId, $status);
    $stmt->execute();
    
    // Get output parameters
    $result = $conn->query("SELECT @success as success, @message as message");
    $output = $result->fetch_assoc();
    
    return [
        'success' => (bool)$output['success'],
        'message' => $output['message']
    ];
}

/**
 * Create a new event using the stored procedure
 * @param int $clubId Club ID
 * @param string $eventName Event name
 * @param string $description Event description
 * @param string $eventDate Event date (format: 'Y-m-d H:i:s')
 * @param string $location Event location
 * @param int $createdBy User ID of creator
 * @return array Result with success status, message, and event ID
 */
function createEventProcedure($clubId, $eventName, $description, $eventDate, $location, $createdBy) {
    $conn = getDBConnection();
    
    // Initialize output parameters
    $conn->query("SET @success = 0");
    $conn->query("SET @message = ''");
    $conn->query("SET @event_id = 0");
    
    // Call the stored procedure
    $stmt = $conn->prepare("CALL CreateEvent(?, ?, ?, ?, ?, ?, @success, @message, @event_id)");
    $stmt->bind_param("issssi", $clubId, $eventName, $description, $eventDate, $location, $createdBy);
    $stmt->execute();
    
    // Get output parameters
    $result = $conn->query("SELECT @success as success, @message as message, @event_id as event_id");
    $output = $result->fetch_assoc();
    
    return [
        'success' => (bool)$output['success'],
        'message' => $output['message'],
        'event_id' => (int)$output['event_id']
    ];
}

/**
 * Update event status using the stored procedure
 * @param int $eventId Event ID
 * @param int $userId User ID performing the update
 * @param string $newStatus New status ('upcoming', 'ongoing', 'completed', 'cancelled')
 * @return array Result with success status and message
 */
function updateEventStatusProcedure($eventId, $userId, $newStatus) {
    $conn = getDBConnection();
    
    // Validate status
    if (!in_array($newStatus, ['upcoming', 'ongoing', 'completed', 'cancelled'])) {
        return [
            'success' => false,
            'message' => 'Invalid status. Must be one of: upcoming, ongoing, completed, cancelled'
        ];
    }
    
    // Initialize output parameters
    $conn->query("SET @success = 0");
    $conn->query("SET @message = ''");
    
    // Call the stored procedure
    $stmt = $conn->prepare("CALL UpdateEventStatus(?, ?, ?, @success, @message)");
    $stmt->bind_param("iis", $eventId, $userId, $newStatus);
    $stmt->execute();
    
    // Get output parameters
    $result = $conn->query("SELECT @success as success, @message as message");
    $output = $result->fetch_assoc();
    
    return [
        'success' => (bool)$output['success'],
        'message' => $output['message']
    ];
}

/**
 * Generate a user activity report using the stored procedure
 * @param int $userId User ID
 * @return array Report data with multiple result sets
 */
function generateUserActivityReport($userId) {
    $conn = getDBConnection();
    
    // Call the stored procedure
    $stmt = $conn->prepare("CALL GenerateUserActivityReport(?)");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    
    // Get results
    $report = [];
    
    // Basic user info
    $result = $stmt->get_result();
    $report['user_info'] = $result->fetch_assoc();
    
    // Move to next result set - Clubs joined
    $stmt->next_result();
    $result = $stmt->get_result();
    $report['clubs_joined'] = [];
    while ($row = $result->fetch_assoc()) {
        $report['clubs_joined'][] = $row;
    }
    
    // Move to next result set - Clubs created
    $stmt->next_result();
    $result = $stmt->get_result();
    $report['clubs_created'] = [];
    while ($row = $result->fetch_assoc()) {
        $report['clubs_created'][] = $row;
    }
    
    // Move to next result set - Events created
    $stmt->next_result();
    $result = $stmt->get_result();
    $report['events_created'] = [];
    while ($row = $result->fetch_assoc()) {
        $report['events_created'][] = $row;
    }
    
    // Move to next result set - Upcoming events
    $stmt->next_result();
    $result = $stmt->get_result();
    $report['upcoming_events'] = [];
    while ($row = $result->fetch_assoc()) {
        $report['upcoming_events'][] = $row;
    }
    
    // Move to next result set - Activity summary
    $stmt->next_result();
    $result = $stmt->get_result();
    $report['summary'] = $result->fetch_assoc();
    
    return $report;
}

/**
 * Get recent membership activity logs
 * @param int $limit Limit number of logs returned
 * @return array Array of membership activity logs
 */
function getMembershipLogs($limit = 50) {
    $conn = getDBConnection();
    
    $result = $conn->query("
        SELECT ml.*, 
               CONCAT(u1.first_name, ' ', u1.last_name) as user_name,
               CONCAT(u2.first_name, ' ', u2.last_name) as performed_by_name,
               c.club_name
        FROM membership_log ml
        JOIN users u1 ON ml.user_id = u1.user_id
        JOIN clubs c ON ml.club_id = c.club_id
        LEFT JOIN users u2 ON ml.performed_by = u2.user_id
        ORDER BY ml.action_date DESC
        LIMIT " . (int)$limit
    );
    
    $logs = [];
    while ($row = $result->fetch_assoc()) {
        $logs[] = $row;
    }
    
    return $logs;
}

/**
 * Get recent event status change logs
 * @param int $limit Limit number of logs returned
 * @return array Array of event status change logs
 */
function getEventStatusLogs($limit = 50) {
    $conn = getDBConnection();
    
    $result = $conn->query("
        SELECT el.*,
               e.event_name,
               c.club_name,
               CONCAT(u.first_name, ' ', u.last_name) as performed_by_name
        FROM event_log el
        JOIN events e ON el.event_id = e.event_id
        JOIN clubs c ON e.club_id = c.club_id
        LEFT JOIN users u ON el.performed_by = u.user_id
        ORDER BY el.action_date DESC
        LIMIT " . (int)$limit
    );
    
    $logs = [];
    while ($row = $result->fetch_assoc()) {
        $logs[] = $row;
    }
    
    return $logs;
}
?> 
<?php
require_once __DIR__ . '/../database/db_connect.php';

/**
 * User Management Functions
 */

/**
 * Register a new user
 * @param string $firstName First name
 * @param string $lastName Last name
 * @param string $email Email address
 * @param string $password Password
 * @param string $mobileNo Mobile number
 * @return array Result with success status and message
 */
function registerUser($firstName, $lastName, $email, $password, $mobileNo) {
    $conn = getDBConnection();
    
    // Check if email already exists
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return [
            'success' => false,
            'message' => 'Email already registered'
        ];
    }
    
    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Insert new user
    $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, password, mobile_no) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $firstName, $lastName, $email, $hashedPassword, $mobileNo);
    
    if ($stmt->execute()) {
        $userId = $stmt->insert_id;
        return [
            'success' => true,
            'message' => 'Registration successful',
            'user_id' => $userId
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Registration failed: ' . $conn->error
        ];
    }
}

/**
 * Authenticate a user
 * @param string $email Email address
 * @param string $password Password
 * @return array Result with user data if successful
 */
function loginUser($email, $password) {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("SELECT user_id, first_name, last_name, email, password, role FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return [
            'success' => false,
            'message' => 'Invalid email or password'
        ];
    }
    
    $user = $result->fetch_assoc();
    
    // Verify password
    if (password_verify($password, $user['password'])) {
        // Remove password from user array
        unset($user['password']);
        
        return [
            'success' => true,
            'message' => 'Login successful',
            'user' => $user
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Invalid email or password'
        ];
    }
}

/**
 * Get user profile by ID
 * @param int $userId User ID
 * @return array User data
 */
function getUserById($userId) {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("SELECT user_id, first_name, last_name, email, mobile_no, role, created_at FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return null;
    }
    
    return $result->fetch_assoc();
}

/**
 * Update user profile
 * @param int $userId User ID
 * @param array $data User data to update
 * @return array Result with success status and message
 */
function updateUserProfile($userId, $data) {
    $conn = getDBConnection();
    
    $allowedFields = [
        'first_name' => 's',
        'last_name' => 's',
        'mobile_no' => 's'
    ];
    
    $updates = [];
    $types = '';
    $values = [];
    
    foreach ($data as $field => $value) {
        if (isset($allowedFields[$field])) {
            $updates[] = "$field = ?";
            $types .= $allowedFields[$field];
            $values[] = $value;
        }
    }
    
    if (empty($updates)) {
        return [
            'success' => false,
            'message' => 'No valid fields to update'
        ];
    }
    
    $sql = "UPDATE users SET " . implode(', ', $updates) . " WHERE user_id = ?";
    $types .= 'i';
    $values[] = $userId;
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$values);
    
    if ($stmt->execute()) {
        return [
            'success' => true,
            'message' => 'Profile updated successfully'
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Update failed: ' . $conn->error
        ];
    }
}

/**
 * Change user password
 * @param int $userId User ID
 * @param string $currentPassword Current password
 * @param string $newPassword New password
 * @return array Result with success status and message
 */
function changePassword($userId, $currentPassword, $newPassword) {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("SELECT password FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return [
            'success' => false,
            'message' => 'User not found'
        ];
    }
    
    $user = $result->fetch_assoc();
    
    // Verify current password
    if (!password_verify($currentPassword, $user['password'])) {
        return [
            'success' => false,
            'message' => 'Current password is incorrect'
        ];
    }
    
    // Hash new password
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    
    // Update password
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
    $stmt->bind_param("si", $hashedPassword, $userId);
    
    if ($stmt->execute()) {
        return [
            'success' => true,
            'message' => 'Password changed successfully'
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Password change failed: ' . $conn->error
        ];
    }
}
?> 
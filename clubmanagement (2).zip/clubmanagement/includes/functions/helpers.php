<?php
/**
 * Helper Functions
 */

/**
 * Start a session if not already started
 */
function startSession() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

/**
 * Check if user is logged in
 * @return bool True if logged in, false otherwise
 */
function isLoggedIn() {
    startSession();
    return isset($_SESSION['user_id']);
}

/**
 * Check if current user is an admin
 * @return bool True if admin, false otherwise
 */
function isAdmin() {
    startSession();
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

/**
 * Get current logged in user ID
 * @return int|null User ID or null if not logged in
 */
function getCurrentUserId() {
    startSession();
    return $_SESSION['user_id'] ?? null;
}

/**
 * Redirect to a URL
 * @param string $url URL to redirect to
 */
function redirect($url) {
    header("Location: $url");
    exit;
}

/**
 * Display flash message
 * @param string $type Message type (success, error, info, warning)
 * @param string $message Message content
 */
function setFlashMessage($type, $message) {
    startSession();
    $_SESSION['flash_message'] = [
        'type' => $type,
        'message' => $message
    ];
}

/**
 * Get and clear flash message
 * @return array|null Flash message or null if none
 */
function getFlashMessage() {
    startSession();
    
    if (isset($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message'];
        unset($_SESSION['flash_message']);
        return $message;
    }
    
    return null;
}

/**
 * Clean input data
 * @param string $data Data to clean
 * @return string Cleaned data
 */
function cleanInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Format date time
 * @param string $dateTime Date time string
 * @param string $format Format string (default: 'M d, Y h:i A')
 * @return string Formatted date time
 */
function formatDateTime($dateTime, $format = 'M d, Y h:i A') {
    $dt = new DateTime($dateTime);
    return $dt->format($format);
}

/**
 * Check if user has club role
 * @param int $userId User ID
 * @param int $clubId Club ID
 * @param array $allowedRoles Array of allowed roles
 * @return bool True if user has role, false otherwise
 */
function userHasClubRole($userId, $clubId, $allowedRoles = ['admin', 'moderator']) {
    require_once __DIR__ . '/../database/db_connect.php';
    
    $conn = getDBConnection();
    
    $rolesStr = implode("','", array_map(function($role) use ($conn) {
        return $conn->real_escape_string($role);
    }, $allowedRoles));
    
    $stmt = $conn->prepare("
        SELECT 1 FROM club_members 
        WHERE user_id = ? AND club_id = ? AND role IN ('$rolesStr')
    ");
    $stmt->bind_param("ii", $userId, $clubId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->num_rows > 0;
}

/**
 * Check if current user has club role
 * @param int $clubId Club ID
 * @param array $allowedRoles Array of allowed roles
 * @return bool True if user has role, false otherwise
 */
function currentUserHasClubRole($clubId, $allowedRoles = ['admin', 'moderator']) {
    $userId = getCurrentUserId();
    
    if (!$userId) {
        return false;
    }
    
    return userHasClubRole($userId, $clubId, $allowedRoles);
}

/**
 * Generate pagination HTML
 * @param int $currentPage Current page number
 * @param int $totalPages Total number of pages
 * @param string $urlPattern URL pattern with placeholder for page number (:page)
 * @return string Pagination HTML
 */
function generatePagination($currentPage, $totalPages, $urlPattern) {
    if ($totalPages <= 1) {
        return '';
    }
    
    $html = '<ul class="pagination">';
    
    // Previous button
    if ($currentPage > 1) {
        $prevUrl = str_replace(':page', $currentPage - 1, $urlPattern);
        $html .= '<li><a href="' . $prevUrl . '">&laquo; Previous</a></li>';
    } else {
        $html .= '<li class="disabled"><span>&laquo; Previous</span></li>';
    }
    
    // Page numbers
    $startPage = max(1, $currentPage - 2);
    $endPage = min($totalPages, $currentPage + 2);
    
    if ($startPage > 1) {
        $url = str_replace(':page', 1, $urlPattern);
        $html .= '<li><a href="' . $url . '">1</a></li>';
        if ($startPage > 2) {
            $html .= '<li class="disabled"><span>...</span></li>';
        }
    }
    
    for ($i = $startPage; $i <= $endPage; $i++) {
        if ($i == $currentPage) {
            $html .= '<li class="active"><span>' . $i . '</span></li>';
        } else {
            $url = str_replace(':page', $i, $urlPattern);
            $html .= '<li><a href="' . $url . '">' . $i . '</a></li>';
        }
    }
    
    if ($endPage < $totalPages) {
        if ($endPage < $totalPages - 1) {
            $html .= '<li class="disabled"><span>...</span></li>';
        }
        $url = str_replace(':page', $totalPages, $urlPattern);
        $html .= '<li><a href="' . $url . '">' . $totalPages . '</a></li>';
    }
    
    // Next button
    if ($currentPage < $totalPages) {
        $nextUrl = str_replace(':page', $currentPage + 1, $urlPattern);
        $html .= '<li><a href="' . $nextUrl . '">Next &raquo;</a></li>';
    } else {
        $html .= '<li class="disabled"><span>Next &raquo;</span></li>';
    }
    
    $html .= '</ul>';
    
    return $html;
}
?> 
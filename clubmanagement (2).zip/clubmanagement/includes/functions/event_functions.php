<?php
require_once __DIR__ . '/../database/db_connect.php';

/**
 * Event Management Functions
 */

/**
 * Create a new event
 * @param int $clubId Club ID
 * @param string $eventName Event name
 * @param string $description Event description
 * @param string $eventDate Event date (YYYY-MM-DD HH:MM:SS)
 * @param string $location Event location
 * @param int $createdBy User ID of creator
 * @return array Result with success status and message
 */
function createEvent($clubId, $eventName, $description, $eventDate, $location, $createdBy) {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("
        INSERT INTO events (club_id, event_name, description, event_date, location, created_by) 
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("issssi", $clubId, $eventName, $description, $eventDate, $location, $createdBy);
    
    if ($stmt->execute()) {
        $eventId = $stmt->insert_id;
        return [
            'success' => true,
            'message' => 'Event created successfully',
            'event_id' => $eventId
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Event creation failed: ' . $conn->error
        ];
    }
}

/**
 * Get event details by ID
 * @param int $eventId Event ID
 * @return array Event data
 */
function getEventById($eventId) {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("
        SELECT e.*, c.club_name, 
               u.first_name as creator_first_name, u.last_name as creator_last_name
        FROM events e
        JOIN clubs c ON e.club_id = c.club_id
        JOIN users u ON e.created_by = u.user_id
        WHERE e.event_id = ?
    ");
    $stmt->bind_param("i", $eventId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return null;
    }
    
    return $result->fetch_assoc();
}

/**
 * Get club events
 * @param int $clubId Club ID
 * @param string $status Event status filter (optional)
 * @return array Array of events
 */
function getClubEvents($clubId, $status = null) {
    $conn = getDBConnection();
    
    $sql = "
        SELECT e.*
        FROM events e
        WHERE e.club_id = ?
    ";
    
    if ($status) {
        $sql .= " AND e.status = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $clubId, $status);
    } else {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $clubId);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $events = [];
    while ($row = $result->fetch_assoc()) {
        $events[] = $row;
    }
    
    return $events;
}

/**
 * Get upcoming events for a user
 * @param int $userId User ID
 * @return array Array of events
 */
function getUserUpcomingEvents($userId) {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("
        SELECT e.*, c.club_name
        FROM events e
        JOIN clubs c ON e.club_id = c.club_id
        JOIN club_members cm ON e.club_id = cm.club_id
        WHERE cm.user_id = ? AND e.status = 'upcoming' AND e.event_date > NOW()
        ORDER BY e.event_date
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $events = [];
    while ($row = $result->fetch_assoc()) {
        $events[] = $row;
    }
    
    return $events;
}

/**
 * Update event status
 * @param int $eventId Event ID
 * @param string $status New status
 * @return array Result with success status and message
 */
function updateEventStatus($eventId, $status) {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("UPDATE events SET status = ? WHERE event_id = ?");
    $stmt->bind_param("si", $status, $eventId);
    
    if ($stmt->execute()) {
        return [
            'success' => true,
            'message' => 'Event status updated successfully'
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Failed to update event status: ' . $conn->error
        ];
    }
}

/**
 * Update event details
 * @param int $eventId Event ID
 * @param array $data Event data to update
 * @return array Result with success status and message
 */
function updateEvent($eventId, $data) {
    $conn = getDBConnection();
    
    $allowedFields = [
        'event_name' => 's',
        'description' => 's',
        'event_date' => 's',
        'location' => 's',
        'status' => 's'
    ];
    
    $updates = [];
    $types = '';
    $values = [];
    
    foreach ($data as $field => $value) {
        if (isset($allowedFields[$field])) {
            $updates[] = "$field = ?";
            $types .= $allowedFields[$field];
            $values[] = $value;
        }
    }
    
    if (empty($updates)) {
        return [
            'success' => false,
            'message' => 'No valid fields to update'
        ];
    }
    
    $sql = "UPDATE events SET " . implode(', ', $updates) . " WHERE event_id = ?";
    $types .= 'i';
    $values[] = $eventId;
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$values);
    
    if ($stmt->execute()) {
        return [
            'success' => true,
            'message' => 'Event updated successfully'
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Update failed: ' . $conn->error
        ];
    }
}

/**
 * Delete an event
 * @param int $eventId Event ID
 * @return array Result with success status and message
 */
function deleteEvent($eventId) {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("DELETE FROM events WHERE event_id = ?");
    $stmt->bind_param("i", $eventId);
    
    if ($stmt->execute()) {
        return [
            'success' => true,
            'message' => 'Event deleted successfully'
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Failed to delete event: ' . $conn->error
        ];
    }
}
?> 
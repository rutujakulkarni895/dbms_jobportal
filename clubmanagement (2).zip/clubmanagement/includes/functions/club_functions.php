<?php
require_once __DIR__ . '/../database/db_connect.php';

/**
 * Club Management Functions
 */

/**
 * Create a new club
 * @param string $clubName Name of the club
 * @param string $description Club description
 * @param int $createdBy User ID of the creator
 * @return array Result with success status and message
 */
function createClub($clubName, $description, $createdBy) {
    $conn = getDBConnection();
    
    // Check if club name already exists
    $stmt = $conn->prepare("SELECT club_id FROM clubs WHERE club_name = ?");
    $stmt->bind_param("s", $clubName);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return [
            'success' => false,
            'message' => 'Club name already exists'
        ];
    }
    
    // Insert new club
    $stmt = $conn->prepare("INSERT INTO clubs (club_name, description, created_by) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $clubName, $description, $createdBy);
    
    if ($stmt->execute()) {
        $clubId = $stmt->insert_id;
        
        // Make creator an admin of the club
        $stmt = $conn->prepare("INSERT INTO club_members (user_id, club_id, role) VALUES (?, ?, 'admin')");
        $stmt->bind_param("ii", $createdBy, $clubId);
        $stmt->execute();
        
        return [
            'success' => true,
            'message' => 'Club created successfully',
            'club_id' => $clubId
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Club creation failed: ' . $conn->error
        ];
    }
}

/**
 * Get club details by ID
 * @param int $clubId Club ID
 * @return array Club data
 */
function getClubById($clubId) {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("
        SELECT c.*, 
               (SELECT COUNT(*) FROM club_members WHERE club_id = c.club_id) as total_members,
               (SELECT COUNT(*) FROM membership_requests WHERE club_id = c.club_id AND status = 'pending') as pending_requests,
               (SELECT COUNT(*) FROM events WHERE club_id = c.club_id AND status = 'upcoming') as upcoming_events,
               u.first_name as creator_first_name, u.last_name as creator_last_name
        FROM clubs c
        LEFT JOIN users u ON c.created_by = u.user_id
        WHERE c.club_id = ?
    ");
    $stmt->bind_param("i", $clubId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return null;
    }
    
    return $result->fetch_assoc();
}

/**
 * Get all clubs
 * @return array Array of clubs
 */
function getAllClubs() {
    $conn = getDBConnection();
    
    $result = $conn->query("
        SELECT c.*, 
               (SELECT COUNT(*) FROM club_members WHERE club_id = c.club_id) as total_members,
               (SELECT COUNT(*) FROM events WHERE club_id = c.club_id AND status = 'upcoming') as upcoming_events
        FROM clubs c
        ORDER BY c.club_name
    ");
    
    $clubs = [];
    while ($row = $result->fetch_assoc()) {
        $clubs[] = $row;
    }
    
    return $clubs;
}

/**
 * Get clubs a user is a member of
 * @param int $userId User ID
 * @return array Array of clubs
 */
function getUserClubs($userId) {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("
        SELECT c.*, cm.role as member_role, cm.member_id 
        FROM clubs c
        JOIN club_members cm ON c.club_id = cm.club_id
        WHERE cm.user_id = ?
        ORDER BY c.club_name
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $clubs = [];
    while ($row = $result->fetch_assoc()) {
        $clubs[] = $row;
    }
    
    return $clubs;
}

/**
 * Submit a membership request
 * @param int $userId User ID
 * @param int $clubId Club ID
 * @return array Result with success status and message
 */
function requestClubMembership($userId, $clubId) {
    $conn = getDBConnection();
    
    // Check if user is already a member
    $stmt = $conn->prepare("SELECT member_id FROM club_members WHERE user_id = ? AND club_id = ?");
    $stmt->bind_param("ii", $userId, $clubId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return [
            'success' => false,
            'message' => 'You are already a member of this club'
        ];
    }
    
    // Check if request already exists
    $stmt = $conn->prepare("SELECT req_id FROM membership_requests WHERE user_id = ? AND club_id = ? AND status = 'pending'");
    $stmt->bind_param("ii", $userId, $clubId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return [
            'success' => false,
            'message' => 'You already have a pending request for this club'
        ];
    }
    
    // Insert membership request
    $stmt = $conn->prepare("INSERT INTO membership_requests (user_id, club_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $userId, $clubId);
    
    if ($stmt->execute()) {
        return [
            'success' => true,
            'message' => 'Membership request submitted successfully'
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Request submission failed: ' . $conn->error
        ];
    }
}

/**
 * Get pending membership requests for a club
 * @param int $clubId Club ID
 * @return array Array of pending requests
 */
function getPendingClubRequests($clubId) {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("
        SELECT mr.*, u.first_name, u.last_name, u.email
        FROM membership_requests mr
        JOIN users u ON mr.user_id = u.user_id
        WHERE mr.club_id = ? AND mr.status = 'pending'
        ORDER BY mr.request_date
    ");
    $stmt->bind_param("i", $clubId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $requests = [];
    while ($row = $result->fetch_assoc()) {
        $requests[] = $row;
    }
    
    return $requests;
}

/**
 * Process a membership request
 * @param int $requestId Request ID
 * @param string $status New status ('approved' or 'rejected')
 * @return array Result with success status and message
 */
function processMembershipRequest($requestId, $status) {
    $conn = getDBConnection();
    
    // Get request details
    $stmt = $conn->prepare("SELECT user_id, club_id FROM membership_requests WHERE req_id = ?");
    $stmt->bind_param("i", $requestId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return [
            'success' => false,
            'message' => 'Request not found'
        ];
    }
    
    $request = $result->fetch_assoc();
    
    // Update request status
    $stmt = $conn->prepare("UPDATE membership_requests SET status = ?, response_date = NOW() WHERE req_id = ?");
    $stmt->bind_param("si", $status, $requestId);
    
    if (!$stmt->execute()) {
        return [
            'success' => false,
            'message' => 'Failed to update request: ' . $conn->error
        ];
    }
    
    // If approved, add user to club members
    if ($status === 'approved') {
        $stmt = $conn->prepare("INSERT INTO club_members (user_id, club_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $request['user_id'], $request['club_id']);
        
        if (!$stmt->execute()) {
            return [
                'success' => false,
                'message' => 'Failed to add member: ' . $conn->error
            ];
        }
    }
    
    return [
        'success' => true,
        'message' => 'Request processed successfully'
    ];
}

/**
 * Get club members
 * @param int $clubId Club ID
 * @return array Array of members
 */
function getClubMembers($clubId) {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("
        SELECT cm.*, u.first_name, u.last_name, u.email
        FROM club_members cm
        JOIN users u ON cm.user_id = u.user_id
        WHERE cm.club_id = ?
        ORDER BY cm.role, u.first_name, u.last_name
    ");
    $stmt->bind_param("i", $clubId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $members = [];
    while ($row = $result->fetch_assoc()) {
        $members[] = $row;
    }
    
    return $members;
}

/**
 * Update member role
 * @param int $memberId Member ID
 * @param string $role New role
 * @return array Result with success status and message
 */
function updateMemberRole($memberId, $role) {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("UPDATE club_members SET role = ? WHERE member_id = ?");
    $stmt->bind_param("si", $role, $memberId);
    
    if ($stmt->execute()) {
        return [
            'success' => true,
            'message' => 'Member role updated successfully'
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Failed to update role: ' . $conn->error
        ];
    }
}

/**
 * Remove a member from a club
 * @param int $memberId Member ID
 * @return array Result with success status and message
 */
function removeMember($memberId) {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("DELETE FROM club_members WHERE member_id = ?");
    $stmt->bind_param("i", $memberId);
    
    if ($stmt->execute()) {
        return [
            'success' => true,
            'message' => 'Member removed successfully'
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Failed to remove member: ' . $conn->error
        ];
    }
}
?> 
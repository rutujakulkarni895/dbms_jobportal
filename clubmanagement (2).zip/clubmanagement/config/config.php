<?php
/**
 * Application Configuration
 */

// Application settings
define('APP_NAME', 'Club Management System');
define('APP_VERSION', '1.0.0');
define('BASE_URL', 'http://localhost/clubmanagement');

// Database settings are in includes/database/db_connect.php

// Session settings
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 0); // Set to 1 if using HTTPS

// Error reporting (disable in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Default time zone
date_default_timezone_set('UTC');

// Include core functions
require_once __DIR__ . '/../includes/database/db_connect.php';
require_once __DIR__ . '/../includes/functions/helpers.php';
require_once __DIR__ . '/../includes/functions/user_functions.php';
require_once __DIR__ . '/../includes/functions/club_functions.php';
require_once __DIR__ . '/../includes/functions/event_functions.php';
require_once __DIR__ . '/../includes/functions/db_features.php';
?> 
<?php
/**
 * Club Management System
 * Main Entry Point
 */

// Include configuration
require_once 'config/config.php';

// Start session
startSession();

// Include header
include 'partials/header.php';

// Check if user is logged in
if (isLoggedIn()) {
    // Get user clubs
    $userClubs = getUserClubs(getCurrentUserId());
    
    // Get upcoming events for user
    $upcomingEvents = getUserUpcomingEvents(getCurrentUserId());
    
    // Include dashboard
    include 'pages/dashboard.php';
} else {
    // Show home page for non-logged in users
    include 'pages/home.php';
}

// Include footer
include 'partials/footer.php';
?> 
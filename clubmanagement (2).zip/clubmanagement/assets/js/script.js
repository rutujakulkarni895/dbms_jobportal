/**
 * Club Management System
 * Custom JavaScript
 */

// Document Ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Auto-dismiss alerts after 5 seconds
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert.alert-dismissible');
        alerts.forEach(function(alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);
    
    // Confirm Delete
    const confirmDelete = document.querySelectorAll('.confirm-delete');
    confirmDelete.forEach(function(button) {
        button.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
                e.preventDefault();
            }
        });
    });
    
    // Form Validation
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
    
    // Date Picker Enhancement
    const datePickers = document.querySelectorAll('.datepicker');
    datePickers.forEach(function(input) {
        input.addEventListener('focus', function() {
            this.type = 'date';
        });
        input.addEventListener('blur', function() {
            if (!this.value) {
                this.type = 'text';
            }
        });
    });
    
    // Dynamic Form Fields
    const addFieldButton = document.getElementById('add-field');
    if (addFieldButton) {
        addFieldButton.addEventListener('click', function() {
            const container = document.getElementById('dynamic-fields');
            const fieldCount = container.querySelectorAll('.dynamic-field').length;
            
            const fieldWrapper = document.createElement('div');
            fieldWrapper.className = 'dynamic-field mb-3';
            
            const newField = document.createElement('input');
            newField.type = 'text';
            newField.className = 'form-control';
            newField.name = 'dynamic_field[' + fieldCount + ']';
            newField.placeholder = 'Field ' + (fieldCount + 1);
            
            const removeButton = document.createElement('button');
            removeButton.type = 'button';
            removeButton.className = 'btn btn-sm btn-danger mt-1';
            removeButton.textContent = 'Remove';
            removeButton.addEventListener('click', function() {
                container.removeChild(fieldWrapper);
            });
            
            fieldWrapper.appendChild(newField);
            fieldWrapper.appendChild(removeButton);
            container.appendChild(fieldWrapper);
        });
    }
}); 
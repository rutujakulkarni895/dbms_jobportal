-- ----------------------
-- Club Management System
-- Database Features Master File
-- ----------------------

-- This file combines all database features (Views, Triggers, Procedures)
-- Run this file to set up all advanced database features at once

-- Start with a clean state by dropping existing objects
USE club_management;

-- Drop procedures (in case they already exist)
DROP PROCEDURE IF EXISTS JoinClub;
DROP PROCEDURE IF EXISTS ProcessMembershipRequest;
DROP PROCEDURE IF EXISTS CreateEvent;
DROP PROCEDURE IF EXISTS UpdateEventStatus;
DROP PROCEDURE IF EXISTS GenerateUserActivityReport;

-- Drop events
DROP EVENT IF EXISTS update_event_status;

-- Drop triggers
DROP TRIGGER IF EXISTS after_club_member_insert;
DROP TRIGGER IF EXISTS after_club_member_delete;
DROP TRIGGER IF EXISTS after_club_member_update;
DROP TRIGGER IF EXISTS after_event_update;

-- Drop views
DROP VIEW IF EXISTS ClubMembershipView;
DROP VIEW IF EXISTS UpcomingEventsView;
DROP VIEW IF EXISTS UserActivityView;
DROP VIEW IF EXISTS ClubEventSummaryView;

-- Create log tables
-- ----------------------
-- Create a table to log membership changes
CREATE TABLE IF NOT EXISTS membership_log (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    club_id INT NOT NULL,
    action VARCHAR(50) NOT NULL,
    role VARCHAR(20),
    action_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    performed_by INT,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (club_id) REFERENCES clubs(club_id),
    FOREIGN KEY (performed_by) REFERENCES users(user_id)
);

-- Create a table to log event status changes
CREATE TABLE IF NOT EXISTS event_log (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    old_status VARCHAR(20),
    new_status VARCHAR(20) NOT NULL,
    action_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    performed_by INT,
    FOREIGN KEY (event_id) REFERENCES events(event_id),
    FOREIGN KEY (performed_by) REFERENCES users(user_id)
);

-- Create Views
-- ----------------------
-- View 1: ClubMembershipView
CREATE VIEW ClubMembershipView AS
SELECT 
    c.club_id,
    c.club_name,
    c.description,
    c.created_at,
    u.user_id AS creator_id,
    CONCAT(u.first_name, ' ', u.last_name) AS creator_name,
    COUNT(DISTINCT cm.user_id) AS member_count,
    COUNT(DISTINCT CASE WHEN e.status = 'upcoming' THEN e.event_id END) AS upcoming_events_count,
    COUNT(DISTINCT CASE WHEN mr.status = 'pending' THEN mr.req_id END) AS pending_requests_count
FROM 
    clubs c
LEFT JOIN 
    users u ON c.created_by = u.user_id
LEFT JOIN 
    club_members cm ON c.club_id = cm.club_id
LEFT JOIN 
    events e ON c.club_id = e.club_id
LEFT JOIN 
    membership_requests mr ON c.club_id = mr.club_id
GROUP BY 
    c.club_id;

-- View 2: UpcomingEventsView
CREATE VIEW UpcomingEventsView AS
SELECT 
    e.event_id,
    e.event_name,
    e.description,
    e.event_date,
    e.location,
    e.status,
    e.created_at,
    c.club_id,
    c.club_name,
    CONCAT(u.first_name, ' ', u.last_name) AS creator_name,
    (SELECT COUNT(*) FROM club_members WHERE club_id = c.club_id) AS club_member_count
FROM 
    events e
JOIN 
    clubs c ON e.club_id = c.club_id
JOIN 
    users u ON e.created_by = u.user_id
WHERE 
    e.event_date > NOW() AND e.status = 'upcoming'
ORDER BY 
    e.event_date;

-- View 3: UserActivityView
CREATE VIEW UserActivityView AS
SELECT 
    u.user_id,
    u.first_name,
    u.last_name,
    u.email,
    u.role,
    u.created_at AS user_joined_date,
    COUNT(DISTINCT cm.club_id) AS clubs_joined,
    COUNT(DISTINCT CASE WHEN c.created_by = u.user_id THEN c.club_id END) AS clubs_created,
    COUNT(DISTINCT CASE WHEN e.created_by = u.user_id THEN e.event_id END) AS events_created,
    COUNT(DISTINCT CASE WHEN cm2.club_id IS NOT NULL AND e2.event_id IS NOT NULL AND e2.event_date > NOW() THEN e2.event_id END) AS upcoming_events
FROM 
    users u
LEFT JOIN 
    club_members cm ON u.user_id = cm.user_id
LEFT JOIN 
    clubs c ON u.user_id = c.created_by
LEFT JOIN 
    events e ON u.user_id = e.created_by
LEFT JOIN 
    club_members cm2 ON u.user_id = cm2.user_id
LEFT JOIN 
    events e2 ON cm2.club_id = e2.club_id AND e2.event_date > NOW() AND e2.status = 'upcoming'
GROUP BY 
    u.user_id;

-- View 4: ClubEventSummaryView
CREATE VIEW ClubEventSummaryView AS
SELECT 
    c.club_id,
    c.club_name,
    COUNT(e.event_id) AS total_events,
    COUNT(CASE WHEN e.status = 'upcoming' THEN 1 END) AS upcoming_events,
    COUNT(CASE WHEN e.status = 'ongoing' THEN 1 END) AS ongoing_events,
    COUNT(CASE WHEN e.status = 'completed' THEN 1 END) AS completed_events,
    COUNT(CASE WHEN e.status = 'cancelled' THEN 1 END) AS cancelled_events,
    MIN(CASE WHEN e.event_date > NOW() THEN e.event_date END) AS next_event_date
FROM 
    clubs c
LEFT JOIN 
    events e ON c.club_id = e.club_id
GROUP BY 
    c.club_id;

-- Create Triggers
-- ----------------------
DELIMITER //

-- Trigger 1: Log Member Addition
CREATE TRIGGER after_club_member_insert
AFTER INSERT ON club_members
FOR EACH ROW
BEGIN
    -- Get the current user ID (since MySQL doesn't store session variables like PHP)
    -- In a real application, you'd pass this from your application
    DECLARE current_user_id INT;
    SET current_user_id = NEW.user_id; -- Assumption: the user who is being added is doing the action
    
    -- Insert log entry
    INSERT INTO membership_log (user_id, club_id, action, role, performed_by)
    VALUES (NEW.user_id, NEW.club_id, 'JOINED', NEW.role, current_user_id);
END //

-- Trigger 2: Log Member Removal
CREATE TRIGGER after_club_member_delete
AFTER DELETE ON club_members
FOR EACH ROW
BEGIN
    -- Get the current user ID (since MySQL doesn't store session variables like PHP)
    -- In a real application, you'd pass this from your application
    DECLARE current_user_id INT;
    SET current_user_id = OLD.user_id; -- Assumption: the user being removed is doing the action
    
    -- Insert log entry
    INSERT INTO membership_log (user_id, club_id, action, role, performed_by)
    VALUES (OLD.user_id, OLD.club_id, 'LEFT', OLD.role, current_user_id);
END //

-- Trigger 3: Log Member Role Update
CREATE TRIGGER after_club_member_update
AFTER UPDATE ON club_members
FOR EACH ROW
BEGIN
    -- Declare variables first, at the beginning of the block
    DECLARE current_user_id INT;
    
    -- Only log if the role has changed
    IF OLD.role <> NEW.role THEN
        -- Set the variable after declaration
        SET current_user_id = NEW.user_id; -- Placeholder, in reality would be the admin who changed the role
        
        -- Insert log entry
        INSERT INTO membership_log (user_id, club_id, action, role, performed_by)
        VALUES (NEW.user_id, NEW.club_id, CONCAT('ROLE_CHANGED_FROM_', OLD.role, '_TO_', NEW.role), NEW.role, current_user_id);
    END IF;
END //

-- Trigger 4: Log Event Status Change
CREATE TRIGGER after_event_update
AFTER UPDATE ON events
FOR EACH ROW
BEGIN
    -- Declare variables first, at the beginning of the block
    DECLARE current_user_id INT;
    
    -- Only log if the status has changed
    IF OLD.status <> NEW.status THEN
        -- Set the variable after declaration
        SET current_user_id = NEW.created_by; -- Placeholder, in reality would be the admin who changed the status
        
        -- Insert log entry
        INSERT INTO event_log (event_id, old_status, new_status, performed_by)
        VALUES (NEW.event_id, OLD.status, NEW.status, current_user_id);
    END IF;
END //

-- Create Scheduled Event for Auto-Updates
CREATE EVENT update_event_status
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    -- Update events to 'ongoing' if the event date has passed and status is still 'upcoming'
    UPDATE events 
    SET status = 'ongoing' 
    WHERE event_date <= NOW() 
    AND status = 'upcoming';
    
    -- Update events to 'completed' if 24 hours have passed since the event date and status is still 'ongoing'
    UPDATE events 
    SET status = 'completed' 
    WHERE event_date <= DATE_SUB(NOW(), INTERVAL 24 HOUR) 
    AND status = 'ongoing';
END //

-- Create Stored Procedures
-- ----------------------

-- Procedure 1: Join Club
CREATE PROCEDURE JoinClub(
    IN p_user_id INT,
    IN p_club_id INT,
    IN p_is_direct_join BOOLEAN,  -- TRUE if admin is adding member directly, FALSE if request is needed
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE member_exists INT;
    DECLARE request_exists INT;
    
    -- Check if user is already a member
    SELECT COUNT(*) INTO member_exists
    FROM club_members
    WHERE user_id = p_user_id AND club_id = p_club_id;
    
    IF member_exists > 0 THEN
        SET p_success = FALSE;
        SET p_message = 'User is already a member of this club';
    ELSE
        -- Check if request already exists
        SELECT COUNT(*) INTO request_exists
        FROM membership_requests
        WHERE user_id = p_user_id AND club_id = p_club_id AND status = 'pending';
        
        IF request_exists > 0 AND NOT p_is_direct_join THEN
            SET p_success = FALSE;
            SET p_message = 'Membership request already exists';
        ELSE
            -- Process based on join type
            IF p_is_direct_join THEN
                -- Direct join (admin adding member)
                INSERT INTO club_members (user_id, club_id, role)
                VALUES (p_user_id, p_club_id, 'member');
                
                SET p_success = TRUE;
                SET p_message = 'User successfully added to club';
            ELSE
                -- Submit a request
                INSERT INTO membership_requests (user_id, club_id, status)
                VALUES (p_user_id, p_club_id, 'pending');
                
                SET p_success = TRUE;
                SET p_message = 'Membership request submitted successfully';
            END IF;
        END IF;
    END IF;
END //

-- Procedure 2: Process Membership Request
CREATE PROCEDURE ProcessMembershipRequest(
    IN p_request_id INT,
    IN p_admin_id INT,
    IN p_status VARCHAR(20),  -- 'approved' or 'rejected'
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_user_id INT;
    DECLARE v_club_id INT;
    DECLARE request_exists INT;
    
    -- Check if request exists and is pending
    SELECT COUNT(*) INTO request_exists
    FROM membership_requests
    WHERE req_id = p_request_id AND status = 'pending';
    
    IF request_exists = 0 THEN
        SET p_success = FALSE;
        SET p_message = 'Request not found or already processed';
    ELSE
        -- Get user and club IDs
        SELECT user_id, club_id INTO v_user_id, v_club_id
        FROM membership_requests
        WHERE req_id = p_request_id;
        
        -- Update request status
        UPDATE membership_requests
        SET status = p_status,
            response_date = NOW()
        WHERE req_id = p_request_id;
        
        -- If approved, add member to club
        IF p_status = 'approved' THEN
            INSERT INTO club_members (user_id, club_id, role)
            VALUES (v_user_id, v_club_id, 'member');
            
            -- Log the action
            INSERT INTO membership_log (user_id, club_id, action, role, performed_by)
            VALUES (v_user_id, v_club_id, 'APPROVED_AND_JOINED', 'member', p_admin_id);
        ELSE
            -- Log the rejection
            INSERT INTO membership_log (user_id, club_id, action, performed_by)
            VALUES (v_user_id, v_club_id, 'REQUEST_REJECTED', p_admin_id);
        END IF;
        
        SET p_success = TRUE;
        SET p_message = CONCAT('Request ', LOWER(p_status), ' successfully');
    END IF;
END //

-- Procedure 3: Create Event
CREATE PROCEDURE CreateEvent(
    IN p_club_id INT,
    IN p_event_name VARCHAR(100),
    IN p_description TEXT,
    IN p_event_date DATETIME,
    IN p_location VARCHAR(255),
    IN p_created_by INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255),
    OUT p_event_id INT
)
BEGIN
    DECLARE user_is_member INT;
    DECLARE has_permission BOOLEAN;
    
    -- Check if event date is in the past
    IF p_event_date < NOW() THEN
        SET p_success = FALSE;
        SET p_message = 'Event date cannot be in the past';
    ELSE
        -- Check if user is a member with appropriate permission
        SELECT COUNT(*) INTO user_is_member
        FROM club_members
        WHERE user_id = p_created_by AND club_id = p_club_id AND role IN ('admin', 'moderator');
        
        IF user_is_member = 0 THEN
            SET p_success = FALSE;
            SET p_message = 'User does not have permission to create events for this club';
        ELSE
            -- Insert the event
            INSERT INTO events (club_id, event_name, description, event_date, location, created_by)
            VALUES (p_club_id, p_event_name, p_description, p_event_date, p_location, p_created_by);
            
            SET p_event_id = LAST_INSERT_ID();
            
            -- Log the event creation
            INSERT INTO event_log (event_id, old_status, new_status, performed_by)
            VALUES (p_event_id, NULL, 'upcoming', p_created_by);
            
            SET p_success = TRUE;
            SET p_message = 'Event created successfully';
        END IF;
    END IF;
END //

-- Procedure 4: Update Event Status
CREATE PROCEDURE UpdateEventStatus(
    IN p_event_id INT,
    IN p_user_id INT,
    IN p_new_status VARCHAR(20),
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_club_id INT;
    DECLARE v_current_status VARCHAR(20);
    DECLARE v_user_has_permission INT;
    
    -- Get event details
    SELECT club_id, status INTO v_club_id, v_current_status
    FROM events
    WHERE event_id = p_event_id;
    
    IF v_club_id IS NULL THEN
        SET p_success = FALSE;
        SET p_message = 'Event not found';
    ELSE
        -- Check user permission
        SELECT COUNT(*) INTO v_user_has_permission
        FROM club_members
        WHERE user_id = p_user_id AND club_id = v_club_id AND role IN ('admin', 'moderator');
        
        IF v_user_has_permission = 0 THEN
            SET p_success = FALSE;
            SET p_message = 'User does not have permission to update this event';
        ELSE
            -- Validate status transition
            IF v_current_status = 'cancelled' THEN
                SET p_success = FALSE;
                SET p_message = 'Cannot change status of a cancelled event';
            ELSEIF v_current_status = 'completed' AND p_new_status != 'cancelled' THEN
                SET p_success = FALSE;
                SET p_message = 'Completed events can only be cancelled';
            ELSEIF v_current_status = p_new_status THEN
                SET p_success = FALSE;
                SET p_message = 'Event is already in this status';
            ELSE
                -- Update the event status
                UPDATE events
                SET status = p_new_status
                WHERE event_id = p_event_id;
                
                SET p_success = TRUE;
                SET p_message = 'Event status updated successfully';
            END IF;
        END IF;
    END IF;
END //

-- Procedure 5: Generate User Activity Report
CREATE PROCEDURE GenerateUserActivityReport(
    IN p_user_id INT
)
BEGIN
    -- Basic user info
    SELECT 
        u.user_id,
        CONCAT(u.first_name, ' ', u.last_name) AS full_name,
        u.email,
        u.role,
        u.created_at AS joined_date
    FROM 
        users u
    WHERE 
        u.user_id = p_user_id;
    
    -- Clubs joined
    SELECT 
        c.club_id,
        c.club_name,
        cm.role AS member_role,
        cm.join_date
    FROM 
        clubs c
    JOIN 
        club_members cm ON c.club_id = cm.club_id
    WHERE 
        cm.user_id = p_user_id
    ORDER BY 
        cm.join_date DESC;
    
    -- Clubs created
    SELECT 
        club_id,
        club_name,
        created_at
    FROM 
        clubs
    WHERE 
        created_by = p_user_id
    ORDER BY 
        created_at DESC;
    
    -- Events created
    SELECT 
        e.event_id,
        e.event_name,
        e.event_date,
        e.status,
        c.club_name
    FROM 
        events e
    JOIN 
        clubs c ON e.club_id = c.club_id
    WHERE 
        e.created_by = p_user_id
    ORDER BY 
        e.event_date DESC;
    
    -- Upcoming events for user's clubs
    SELECT 
        e.event_id,
        e.event_name,
        e.event_date,
        c.club_name
    FROM 
        events e
    JOIN 
        clubs c ON e.club_id = c.club_id
    JOIN 
        club_members cm ON c.club_id = cm.club_id
    WHERE 
        cm.user_id = p_user_id
        AND e.event_date > NOW()
        AND e.status = 'upcoming'
    ORDER BY 
        e.event_date;
    
    -- Activity summary
    SELECT 
        (SELECT COUNT(*) FROM club_members WHERE user_id = p_user_id) AS clubs_joined,
        (SELECT COUNT(*) FROM clubs WHERE created_by = p_user_id) AS clubs_created,
        (SELECT COUNT(*) FROM events WHERE created_by = p_user_id) AS events_created,
        (SELECT COUNT(*) FROM events e
         JOIN clubs c ON e.club_id = c.club_id
         JOIN club_members cm ON c.club_id = cm.club_id
         WHERE cm.user_id = p_user_id AND e.event_date > NOW() AND e.status = 'upcoming') AS upcoming_events;
END //

DELIMITER ; 
<?php
/**
 * Admin Dashboard
 * Main admin control panel showing system stats and features
 */

// Include configuration
require_once __DIR__ . '/../../config/config.php';

// Redirect if not logged in or not admin
if (!isLoggedIn()) {
    setFlashMessage('error', 'You must be logged in to view this page.');
    redirect(BASE_URL . '/pages/login.php');
}

$userId = getCurrentUserId();
$user = getUserById($userId);

if ($user['role'] !== 'admin') {
    setFlashMessage('error', 'You do not have permission to view this page.');
    redirect(BASE_URL . '/pages/dashboard.php');
}

// Get data for dashboard
// Get all clubs with membership counts
$clubs = getClubsWithMembership();

// Get upcoming events from view
$upcomingEvents = getUpcomingEventsFromView(5);

// Get user stats for current user
$userStats = getUserActivityStats($userId);

// Get membership logs (latest 5)
$membershipLogs = getMembershipLogs(5);

// Get event logs (latest 5)
$eventLogs = getEventStatusLogs(5);

// Include header
include __DIR__ . '/../../partials/header.php';
?>

<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1>Admin Dashboard</h1>
            <p class="lead">System overview and advanced features</p>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo BASE_URL; ?>/pages/dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Back to User Dashboard
            </a>
        </div>
    </div>
    
    <!-- System Stats -->
    <div class="row mb-4">
        <div class="col-md-3 mb-3">
            <div class="card bg-primary text-white h-100">
                <div class="card-body d-flex flex-column align-items-center">
                    <h1 class="display-4 mb-0"><?php echo count($clubs); ?></h1>
                    <p class="lead">Total Clubs</p>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-3">
            <div class="card bg-success text-white h-100">
                <div class="card-body d-flex flex-column align-items-center">
                    <h1 class="display-4 mb-0">
                        <?php 
                        $totalMembers = 0;
                        foreach ($clubs as $club) {
                            $totalMembers += $club['member_count'];
                        }
                        echo $totalMembers;
                        ?>
                    </h1>
                    <p class="lead">Club Members</p>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-3">
            <div class="card bg-info text-white h-100">
                <div class="card-body d-flex flex-column align-items-center">
                    <h1 class="display-4 mb-0">
                        <?php 
                        $totalEvents = 0;
                        foreach ($clubs as $club) {
                            $totalEvents += $club['upcoming_events_count'];
                        }
                        echo $totalEvents;
                        ?>
                    </h1>
                    <p class="lead">Upcoming Events</p>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-3">
            <div class="card bg-warning text-dark h-100">
                <div class="card-body d-flex flex-column align-items-center">
                    <h1 class="display-4 mb-0">
                        <?php 
                        $totalRequests = 0;
                        foreach ($clubs as $club) {
                            $totalRequests += $club['pending_requests_count'];
                        }
                        echo $totalRequests;
                        ?>
                    </h1>
                    <p class="lead">Pending Requests</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Recent Activity -->
    <div class="row mb-4">
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Membership Activity</h5>
                    <a href="<?php echo BASE_URL; ?>/pages/admin/system_logs.php?type=membership" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body">
                    <?php if (empty($membershipLogs)): ?>
                        <div class="alert alert-info">No recent membership activity.</div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>User</th>
                                        <th>Club</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($membershipLogs as $log): ?>
                                        <tr>
                                            <td><?php echo formatDateTime($log['action_date'], 'M d, H:i'); ?></td>
                                            <td><?php echo htmlspecialchars($log['user_name']); ?></td>
                                            <td><?php echo htmlspecialchars($log['club_name']); ?></td>
                                            <td>
                                                <span class="badge <?php echo getActionBadgeClass($log['action']); ?>">
                                                    <?php echo formatActionName($log['action']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Event Activity</h5>
                    <a href="<?php echo BASE_URL; ?>/pages/admin/system_logs.php?type=events" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body">
                    <?php if (empty($eventLogs)): ?>
                        <div class="alert alert-info">No recent event activity.</div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Event</th>
                                        <th>Status Change</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($eventLogs as $log): ?>
                                        <tr>
                                            <td><?php echo formatDateTime($log['action_date'], 'M d, H:i'); ?></td>
                                            <td><?php echo htmlspecialchars($log['event_name']); ?></td>
                                            <td>
                                                <?php if ($log['old_status']): ?>
                                                    <span class="badge <?php echo getStatusBadgeClass($log['old_status']); ?>">
                                                        <?php echo ucfirst($log['old_status']); ?>
                                                    </span>
                                                    <i class="fas fa-arrow-right mx-1"></i>
                                                <?php endif; ?>
                                                <span class="badge <?php echo getStatusBadgeClass($log['new_status']); ?>">
                                                    <?php echo ucfirst($log['new_status']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Database Feature Cards -->
    <div class="row mb-4">
        <div class="col-12 mb-3">
            <h2>Advanced Database Features</h2>
            <p>These database features have been implemented to enhance system performance and functionality.</p>
        </div>
        
        <div class="col-md-6 col-lg-3 mb-4">
            <div class="card h-100">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Database Views</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">ClubMembershipView</li>
                        <li class="list-group-item">UpcomingEventsView</li>
                        <li class="list-group-item">UserActivityView</li>
                        <li class="list-group-item">ClubEventSummaryView</li>
                    </ul>
                </div>
                <div class="card-footer bg-white">
                    <p class="text-muted small">Views provide simplified access to complex data from multiple tables.</p>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 col-lg-3 mb-4">
            <div class="card h-100">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">Triggers</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">Member Addition Logger</li>
                        <li class="list-group-item">Member Removal Logger</li>
                        <li class="list-group-item">Role Change Logger</li>
                        <li class="list-group-item">Event Status Logger</li>
                    </ul>
                </div>
                <div class="card-footer bg-white">
                    <p class="text-muted small">Triggers automate database actions when specific events occur.</p>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 col-lg-3 mb-4">
            <div class="card h-100">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0">Stored Procedures</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">JoinClub</li>
                        <li class="list-group-item">ProcessMembershipRequest</li>
                        <li class="list-group-item">CreateEvent</li>
                        <li class="list-group-item">UpdateEventStatus</li>
                        <li class="list-group-item">GenerateUserActivityReport</li>
                    </ul>
                </div>
                <div class="card-footer bg-white">
                    <p class="text-muted small">Procedures encapsulate complex database operations.</p>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 col-lg-3 mb-4">
            <div class="card h-100">
                <div class="card-header bg-warning text-dark">
                    <h5 class="mb-0">Events</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <strong>Update Event Status</strong>
                            <p class="small mb-0">Runs daily to automatically update event status based on date</p>
                        </li>
                    </ul>
                </div>
                <div class="card-footer bg-white">
                    <p class="text-muted small">Scheduled events run automatically to maintain system data.</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Admin Actions -->
    <div class="row">
        <div class="col-12 mb-3">
            <h2>Admin Actions</h2>
        </div>
        
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <div class="card-header bg-danger text-white">
                    <h5 class="mb-0">System Logs</h5>
                </div>
                <div class="card-body">
                    <p>View detailed system logs for monitoring and troubleshooting.</p>
                    <a href="<?php echo BASE_URL; ?>/pages/admin/system_logs.php" class="btn btn-outline-danger">View System Logs</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <div class="card-header bg-dark text-white">
                    <h5 class="mb-0">Database Management</h5>
                </div>
                <div class="card-body">
                    <p>Access phpMyAdmin to manage the database directly.</p>
                    <a href="http://localhost/phpmyadmin" target="_blank" class="btn btn-outline-dark">Open phpMyAdmin</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">User Activity Reports</h5>
                </div>
                <div class="card-body">
                    <p>Generate detailed activity reports for any user.</p>
                    <form action="<?php echo BASE_URL; ?>/pages/admin/user_report.php" method="get" class="d-flex">
                        <input type="number" name="user_id" placeholder="User ID" class="form-control me-2" required>
                        <button type="submit" class="btn btn-outline-primary">Generate</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
/**
 * Helper function to get appropriate badge class for action
 */
function getActionBadgeClass($action) {
    switch (strtoupper($action)) {
        case 'JOINED':
            return 'bg-success';
        case 'LEFT':
            return 'bg-danger';
        case 'APPROVED_AND_JOINED':
            return 'bg-primary';
        case 'REQUEST_REJECTED':
            return 'bg-warning text-dark';
        default:
            if (strpos($action, 'ROLE_CHANGED') !== false) {
                return 'bg-info text-dark';
            }
            return 'bg-secondary';
    }
}

/**
 * Helper function to format action name for display
 */
function formatActionName($action) {
    $action = strtoupper($action);
    
    if ($action === 'JOINED') return 'Joined';
    if ($action === 'LEFT') return 'Left';
    if ($action === 'APPROVED_AND_JOINED') return 'Approved & Joined';
    if ($action === 'REQUEST_REJECTED') return 'Request Rejected';
    
    if (strpos($action, 'ROLE_CHANGED') !== false) {
        $parts = explode('_', $action);
        $fromRole = isset($parts[3]) ? ucfirst(strtolower($parts[3])) : '';
        $toRole = isset($parts[5]) ? ucfirst(strtolower($parts[5])) : '';
        return "Role: {$fromRole} → {$toRole}";
    }
    
    return str_replace('_', ' ', ucfirst(strtolower($action)));
}

/**
 * Helper function to get appropriate badge class for status
 */
function getStatusBadgeClass($status) {
    switch (strtolower($status)) {
        case 'upcoming':
            return 'bg-primary';
        case 'ongoing':
            return 'bg-warning text-dark';
        case 'completed':
            return 'bg-success';
        case 'cancelled':
            return 'bg-danger';
        default:
            return 'bg-secondary';
    }
}

// Include footer
include __DIR__ . '/../../partials/footer.php';
?> 
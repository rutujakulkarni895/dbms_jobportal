<?php
/**
 * System Logs Page
 * Admin page to view membership and event logs
 */

// Include configuration
require_once __DIR__ . '/../../config/config.php';

// Redirect if not logged in or not admin
if (!isLoggedIn()) {
    setFlashMessage('error', 'You must be logged in to view this page.');
    redirect(BASE_URL . '/pages/login.php');
}

$userId = getCurrentUserId();
$user = getUserById($userId);

if ($user['role'] !== 'admin') {
    setFlashMessage('error', 'You do not have permission to view this page.');
    redirect(BASE_URL . '/pages/dashboard.php');
}

// Get log type from URL parameter (default to membership)
$logType = isset($_GET['type']) && $_GET['type'] === 'events' ? 'events' : 'membership';

// Get logs based on type
$logs = [];
if ($logType === 'membership') {
    $logs = getMembershipLogs(100);
} else {
    $logs = getEventStatusLogs(100);
}

// Include header
include __DIR__ . '/../../partials/header.php';
?>

<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1>System Logs</h1>
            <p class="lead">View system activity logs for monitoring and troubleshooting</p>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo BASE_URL; ?>/pages/dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Back to Dashboard
            </a>
        </div>
    </div>
    
    <!-- Log Type Tabs -->
    <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
            <a class="nav-link <?php echo $logType === 'membership' ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>/pages/admin/system_logs.php?type=membership">
                <i class="fas fa-users me-2"></i> Membership Logs
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $logType === 'events' ? 'active' : ''; ?>" href="<?php echo BASE_URL; ?>/pages/admin/system_logs.php?type=events">
                <i class="fas fa-calendar-alt me-2"></i> Event Logs
            </a>
        </li>
    </ul>
    
    <!-- Logs Table -->
    <div class="card">
        <div class="card-body">
            <?php if (empty($logs)): ?>
                <div class="alert alert-info">No logs found.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <?php if ($logType === 'membership'): ?>
                                    <th>User</th>
                                    <th>Club</th>
                                    <th>Action</th>
                                    <th>Role</th>
                                    <th>Performed By</th>
                                <?php else: ?>
                                    <th>Event</th>
                                    <th>Club</th>
                                    <th>Old Status</th>
                                    <th>New Status</th>
                                    <th>Performed By</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td><?php echo formatDateTime($log['action_date']); ?></td>
                                    
                                    <?php if ($logType === 'membership'): ?>
                                        <td><?php echo htmlspecialchars($log['user_name']); ?></td>
                                        <td>
                                            <a href="<?php echo BASE_URL; ?>/pages/club_details.php?id=<?php echo $log['club_id']; ?>">
                                                <?php echo htmlspecialchars($log['club_name']); ?>
                                            </a>
                                        </td>
                                        <td>
                                            <span class="badge <?php echo getActionBadgeClass($log['action']); ?>">
                                                <?php echo formatActionName($log['action']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo ucfirst($log['role'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($log['performed_by_name'] ?? 'System'); ?></td>
                                    <?php else: ?>
                                        <td>
                                            <a href="<?php echo BASE_URL; ?>/pages/event_details.php?id=<?php echo $log['event_id']; ?>">
                                                <?php echo htmlspecialchars($log['event_name']); ?>
                                            </a>
                                        </td>
                                        <td>
                                            <a href="<?php echo BASE_URL; ?>/pages/club_details.php?id=<?php echo $log['club_id']; ?>">
                                                <?php echo htmlspecialchars($log['club_name']); ?>
                                            </a>
                                        </td>
                                        <td>
                                            <?php if ($log['old_status']): ?>
                                                <span class="badge <?php echo getStatusBadgeClass($log['old_status']); ?>">
                                                    <?php echo ucfirst($log['old_status']); ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="text-muted">New</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge <?php echo getStatusBadgeClass($log['new_status']); ?>">
                                                <?php echo ucfirst($log['new_status']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($log['performed_by_name'] ?? 'System'); ?></td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
/**
 * Helper function to get appropriate badge class for action
 */
function getActionBadgeClass($action) {
    switch (strtoupper($action)) {
        case 'JOINED':
            return 'bg-success';
        case 'LEFT':
            return 'bg-danger';
        case 'APPROVED_AND_JOINED':
            return 'bg-primary';
        case 'REQUEST_REJECTED':
            return 'bg-warning text-dark';
        default:
            if (strpos($action, 'ROLE_CHANGED') !== false) {
                return 'bg-info text-dark';
            }
            return 'bg-secondary';
    }
}

/**
 * Helper function to format action name for display
 */
function formatActionName($action) {
    $action = strtoupper($action);
    
    if ($action === 'JOINED') return 'Joined';
    if ($action === 'LEFT') return 'Left';
    if ($action === 'APPROVED_AND_JOINED') return 'Approved & Joined';
    if ($action === 'REQUEST_REJECTED') return 'Request Rejected';
    
    if (strpos($action, 'ROLE_CHANGED') !== false) {
        $parts = explode('_', $action);
        $fromRole = isset($parts[3]) ? ucfirst(strtolower($parts[3])) : '';
        $toRole = isset($parts[5]) ? ucfirst(strtolower($parts[5])) : '';
        return "Role: {$fromRole} → {$toRole}";
    }
    
    return str_replace('_', ' ', ucfirst(strtolower($action)));
}

/**
 * Helper function to get appropriate badge class for status
 */
function getStatusBadgeClass($status) {
    switch (strtolower($status)) {
        case 'upcoming':
            return 'bg-primary';
        case 'ongoing':
            return 'bg-warning text-dark';
        case 'completed':
            return 'bg-success';
        case 'cancelled':
            return 'bg-danger';
        default:
            return 'bg-secondary';
    }
}

// Include footer
include __DIR__ . '/../../partials/footer.php';
?> 
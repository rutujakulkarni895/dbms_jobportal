<div class="row">
    <div class="col-md-12 text-center mb-5">
        <h1 class="display-4">Welcome to the Club Management System</h1>
        <p class="lead">Discover, join and participate in clubs and events.</p>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card mb-4">
            <div class="card-body">
                <h2>About Our Platform</h2>
                <p>The Club Management System provides a comprehensive solution for managing clubs and events. Whether you're looking to join existing clubs or create your own, our platform makes it easy to connect with like-minded individuals.</p>
                
                <div class="row mt-4">
                    <div class="col-md-6">
                        <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title"><i class="fas fa-users text-primary me-2"></i> Join Clubs</h5>
                                <p class="card-text">Browse and join clubs based on your interests. Connect with other members and participate in club activities.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title"><i class="fas fa-calendar-alt text-primary me-2"></i> Attend Events</h5>
                                <p class="card-text">Stay up-to-date with upcoming events organized by your clubs. RSVP to events and engage with other attendees.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title"><i class="fas fa-plus-circle text-primary me-2"></i> Create Your Own</h5>
                                <p class="card-text">Start your own club and build a community around your passion. Organize events and grow your membership.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title"><i class="fas fa-bell text-primary me-2"></i> Stay Informed</h5>
                                <p class="card-text">Receive notifications about club activities, upcoming events, and membership requests.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title mb-0">Get Started</h5>
            </div>
            <div class="card-body">
                <p>Join our platform to discover and participate in clubs and events.</p>
                <div class="d-grid gap-2">
                    <a href="<?php echo BASE_URL; ?>/pages/login.php" class="btn btn-primary">Login</a>
                    <a href="<?php echo BASE_URL; ?>/pages/register.php" class="btn btn-outline-primary">Register Now</a>
                </div>
            </div>
        </div>
        
        <?php
        // Get some public stats to display
        require_once __DIR__ . '/../includes/database/db_connect.php';
        $conn = getDBConnection();
        
        // Get club count
        $clubCount = $conn->query("SELECT COUNT(*) as count FROM clubs")->fetch_assoc()['count'];
        
        // Get user count
        $userCount = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];
        
        // Get event count
        $eventCount = $conn->query("SELECT COUNT(*) as count FROM events")->fetch_assoc()['count'];
        ?>
        
        <div class="card">
            <div class="card-header bg-secondary text-white">
                <h5 class="card-title mb-0">Platform Statistics</h5>
            </div>
            <div class="card-body">
                <div class="row text-center">
                    <div class="col-4">
                        <h4><?php echo $clubCount; ?></h4>
                        <p class="text-muted">Clubs</p>
                    </div>
                    <div class="col-4">
                        <h4><?php echo $userCount; ?></h4>
                        <p class="text-muted">Members</p>
                    </div>
                    <div class="col-4">
                        <h4><?php echo $eventCount; ?></h4>
                        <p class="text-muted">Events</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> 
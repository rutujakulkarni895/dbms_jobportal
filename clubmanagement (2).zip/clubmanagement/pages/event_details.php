<?php
/**
 * Event Details Page
 * Displays detailed information about a specific event
 */

// Include configuration
require_once __DIR__ . '/../config/config.php';

// Check if event ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    setFlashMessage('error', 'Event ID is required.');
    redirect(BASE_URL . '/pages/events.php');
}

$eventId = (int)$_GET['id'];

// Get event details
$conn = getDBConnection();
$stmt = $conn->prepare("
    SELECT e.*, c.club_name, c.club_id,
           u.first_name as creator_first_name, u.last_name as creator_last_name
    FROM events e
    JOIN clubs c ON e.club_id = c.club_id
    JOIN users u ON e.created_by = u.user_id
    WHERE e.event_id = ?
");
$stmt->bind_param("i", $eventId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    setFlashMessage('error', 'Event not found.');
    redirect(BASE_URL . '/pages/events.php');
}

$event = $result->fetch_assoc();
$clubId = $event['club_id'];

// Check if user is logged in
$isLoggedIn = isLoggedIn();
$userId = $isLoggedIn ? getCurrentUserId() : null;
$isMember = false;
$memberRole = null;

// Get user's club membership if logged in
if ($isLoggedIn) {
    // Check club membership
    $stmt = $conn->prepare("
        SELECT role FROM club_members
        WHERE club_id = ? AND user_id = ?
    ");
    $stmt->bind_param("ii", $clubId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $isMember = true;
        $memberRole = $result->fetch_assoc()['role'];
    }
}

// Calculate if event is past
$eventDate = new DateTime($event['event_date']);
$currentDate = new DateTime();
$isPastEvent = $eventDate < $currentDate;

// Include header
include __DIR__ . '/../partials/header.php';
?>

<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1><?php echo htmlspecialchars($event['event_name']); ?></h1>
            <p class="lead">
                <a href="<?php echo BASE_URL; ?>/pages/club_details.php?id=<?php echo $event['club_id']; ?>" class="text-decoration-none">
                    <i class="fas fa-users me-2"></i><?php echo htmlspecialchars($event['club_name']); ?>
                </a>
            </p>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo BASE_URL; ?>/pages/events.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Back to Events
            </a>
            
            <?php if ($isLoggedIn && ($isMember && ($memberRole === 'admin' || $memberRole === 'moderator' || $userId === $event['created_by']))): ?>
                <a href="<?php echo BASE_URL; ?>/pages/edit_event.php?id=<?php echo $eventId; ?>" class="btn btn-outline-primary ms-2">
                    <i class="fas fa-edit me-2"></i> Edit Event
                </a>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-3">
                        <div>
                            <h5 class="card-title">
                                <i class="fas fa-calendar-alt me-2 text-primary"></i>
                                <?php echo formatDateTime($event['event_date']); ?>
                            </h5>
                            
                            <?php if (!empty($event['location'])): ?>
                                <p class="card-text mb-0">
                                    <i class="fas fa-map-marker-alt me-2 text-danger"></i>
                                    <?php echo htmlspecialchars($event['location']); ?>
                                </p>
                            <?php endif; ?>
                        </div>
                        
                        <div>
                            <?php
                            $statusBadge = 'bg-primary';
                            if ($event['status'] === 'completed') {
                                $statusBadge = 'bg-success';
                            } elseif ($event['status'] === 'upcoming') {
                                $statusBadge = 'bg-info text-dark';
                            } elseif ($event['status'] === 'ongoing') {
                                $statusBadge = 'bg-warning text-dark';
                            } elseif ($event['status'] === 'cancelled') {
                                $statusBadge = 'bg-danger';
                            }
                            ?>
                            <span class="badge <?php echo $statusBadge; ?> mb-2"><?php echo ucfirst($event['status']); ?></span>
                            
                            <p class="card-text text-muted mb-0">
                                Created by <?php echo htmlspecialchars($event['creator_first_name'] . ' ' . $event['creator_last_name']); ?>
                            </p>
                        </div>
                    </div>
                    
                    <div class="my-4">
                        <h5>Description</h5>
                        <div class="card-text">
                            <?php echo nl2br(htmlspecialchars($event['description'])); ?>
                        </div>
                    </div>
                    
                    <?php if (!$isLoggedIn): ?>
                        <div class="alert alert-info mt-4">
                            <p class="mb-0">
                                <i class="fas fa-info-circle me-2"></i> You need to be logged in to view all event details.
                                <a href="<?php echo BASE_URL; ?>/pages/login.php" class="alert-link">Log in</a> or 
                                <a href="<?php echo BASE_URL; ?>/pages/register.php" class="alert-link">register</a> to see more.
                            </p>
                        </div>
                    <?php elseif (!$isMember): ?>
                        <div class="alert alert-warning mt-4">
                            <p class="mb-0">
                                <i class="fas fa-info-circle me-2"></i> You must be a member of <?php echo htmlspecialchars($event['club_name']); ?> to access all event details.
                                <a href="<?php echo BASE_URL; ?>/pages/club_details.php?id=<?php echo $clubId; ?>" class="alert-link">Join this club</a> to see more.
                            </p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Event Details</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <span><i class="fas fa-users me-2"></i> Club</span>
                            <p class="mb-0">
                                <a href="<?php echo BASE_URL; ?>/pages/club_details.php?id=<?php echo $clubId; ?>" class="text-decoration-none">
                                    <?php echo htmlspecialchars($event['club_name']); ?>
                                </a>
                            </p>
                        </li>
                        <li class="list-group-item">
                            <span><i class="fas fa-calendar-day me-2"></i> Date</span>
                            <p class="text-muted mb-0"><?php echo formatDateTime($event['event_date'], 'F j, Y'); ?></p>
                        </li>
                        <li class="list-group-item">
                            <span><i class="fas fa-clock me-2"></i> Time</span>
                            <p class="text-muted mb-0"><?php echo formatDateTime($event['event_date'], 'g:i A'); ?></p>
                        </li>
                        <?php if (!empty($event['location'])): ?>
                            <li class="list-group-item">
                                <span><i class="fas fa-map-marked-alt me-2"></i> Location</span>
                                <p class="text-muted mb-0"><?php echo htmlspecialchars($event['location']); ?></p>
                            </li>
                        <?php endif; ?>
                        <li class="list-group-item">
                            <span><i class="fas fa-calendar-plus me-2"></i> Created</span>
                            <p class="text-muted mb-0"><?php echo formatDateTime($event['created_at']); ?></p>
                        </li>
                        <li class="list-group-item">
                            <span><i class="fas fa-user me-2"></i> Created By</span>
                            <p class="text-muted mb-0"><?php echo htmlspecialchars($event['creator_first_name'] . ' ' . $event['creator_last_name']); ?></p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <?php if ($isLoggedIn && $isMember && ($memberRole === 'admin' || $memberRole === 'moderator' || $userId === $event['created_by'])): ?>
        <div class="row mt-4">
            <div class="col-12">
                <div class="card border-danger">
                    <div class="card-header bg-danger text-white">
                        <h5 class="mb-0">Admin Actions</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($event['status'] !== 'cancelled'): ?>
                            <div class="d-flex gap-2">
                                <?php if ($event['status'] === 'upcoming'): ?>
                                    <a href="<?php echo BASE_URL; ?>/pages/update_event_status.php?id=<?php echo $eventId; ?>&status=ongoing" class="btn btn-warning" onclick="return confirm('Mark this event as ongoing?');">
                                        <i class="fas fa-hourglass-half me-2"></i> Mark as Ongoing
                                    </a>
                                <?php endif; ?>
                                
                                <?php if ($event['status'] === 'upcoming' || $event['status'] === 'ongoing'): ?>
                                    <a href="<?php echo BASE_URL; ?>/pages/update_event_status.php?id=<?php echo $eventId; ?>&status=completed" class="btn btn-success" onclick="return confirm('Mark this event as completed?');">
                                        <i class="fas fa-check me-2"></i> Mark as Completed
                                    </a>
                                    
                                    <a href="<?php echo BASE_URL; ?>/pages/update_event_status.php?id=<?php echo $eventId; ?>&status=cancelled" class="btn btn-outline-danger" onclick="return confirm('Are you sure you want to cancel this event?');">
                                        <i class="fas fa-ban me-2"></i> Cancel Event
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-danger mb-0">
                                <p class="mb-0">This event has been cancelled. You can still edit the details or delete it.</p>
                            </div>
                        <?php endif; ?>
                        
                        <hr>
                        
                        <div class="d-flex justify-content-between">
                            <a href="<?php echo BASE_URL; ?>/pages/edit_event.php?id=<?php echo $eventId; ?>" class="btn btn-primary">
                                <i class="fas fa-edit me-2"></i> Edit Event
                            </a>
                            
                            <a href="<?php echo BASE_URL; ?>/pages/delete_event.php?id=<?php echo $eventId; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to permanently delete this event? This action cannot be undone!');">
                                <i class="fas fa-trash-alt me-2"></i> Delete Event
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php
// Include footer
include __DIR__ . '/../partials/footer.php';
?> 
<?php
/**
 * User Profile Page
 */

// Include configuration
require_once __DIR__ . '/../config/config.php';

// Redirect if not logged in
if (!isLoggedIn()) {
    setFlashMessage('error', 'You must be logged in to view your profile.');
    redirect(BASE_URL . '/pages/login.php');
}

$userId = getCurrentUserId();
$user = getUserById($userId);

if (!$user) {
    setFlashMessage('error', 'User not found.');
    redirect(BASE_URL);
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $firstName = cleanInput($_POST['first_name'] ?? '');
    $lastName = cleanInput($_POST['last_name'] ?? '');
    $mobileNo = cleanInput($_POST['mobile_no'] ?? '');
    
    // Validate form
    $errors = [];
    
    if (empty($firstName)) {
        $errors[] = 'First name is required';
    }
    
    if (empty($lastName)) {
        $errors[] = 'Last name is required';
    }
    
    // Attempt profile update if no errors
    if (empty($errors)) {
        $data = [
            'first_name' => $firstName,
            'last_name' => $lastName,
            'mobile_no' => $mobileNo
        ];
        
        $result = updateUserProfile($userId, $data);
        
        if ($result['success']) {
            // Update session
            $_SESSION['first_name'] = $firstName;
            $_SESSION['last_name'] = $lastName;
            
            // Set success message
            setFlashMessage('success', 'Profile updated successfully.');
            
            // Refresh user data
            $user = getUserById($userId);
        } else {
            $errors[] = $result['message'];
        }
    }
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    
    // Validate form
    $passwordErrors = [];
    
    if (empty($currentPassword)) {
        $passwordErrors[] = 'Current password is required';
    }
    
    if (empty($newPassword)) {
        $passwordErrors[] = 'New password is required';
    } elseif (strlen($newPassword) < 8) {
        $passwordErrors[] = 'New password must be at least 8 characters long';
    }
    
    if ($newPassword !== $confirmPassword) {
        $passwordErrors[] = 'New passwords do not match';
    }
    
    // Attempt password change if no errors
    if (empty($passwordErrors)) {
        $result = changePassword($userId, $currentPassword, $newPassword);
        
        if ($result['success']) {
            // Set success message
            setFlashMessage('success', 'Password changed successfully.');
            
            // Redirect to refresh the page
            redirect(BASE_URL . '/pages/profile.php');
        } else {
            $passwordErrors[] = $result['message'];
        }
    }
}

// Include header
include __DIR__ . '/../partials/header.php';
?>

<div class="row">
    <div class="col-md-12 mb-4">
        <h1>My Profile</h1>
    </div>
</div>

<div class="row">
    <div class="col-md-4">
        <div class="profile-header">
            <h3><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></h3>
            <div class="user-role"><?php echo ucfirst($user['role']); ?></div>
            <p class="mb-1"><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
            <p class="mb-1"><strong>Mobile:</strong> <?php echo htmlspecialchars($user['mobile_no'] ?: 'Not provided'); ?></p>
            <p class="mb-0"><strong>Member Since:</strong> <?php echo formatDateTime($user['created_at'], 'M d, Y'); ?></p>
        </div>
        
        <?php 
        // Get user stats
        $conn = getDBConnection();
        
        // Club count
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM club_members WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $clubCount = $stmt->get_result()->fetch_assoc()['count'];
        
        // Clubs created count
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM clubs WHERE created_by = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $clubsCreatedCount = $stmt->get_result()->fetch_assoc()['count'];
        
        // Get upcoming events count (replacing events attending count)
        $stmt = $conn->prepare("
            SELECT COUNT(*) as count 
            FROM events e
            JOIN club_members cm ON e.club_id = cm.club_id
            WHERE cm.user_id = ? AND e.status = 'upcoming' AND e.event_date > NOW()
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $upcomingEventsCount = $stmt->get_result()->fetch_assoc()['count'];
        ?>
        
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Activity Summary</h5>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Clubs Joined
                        <span class="badge bg-primary rounded-pill"><?php echo $clubCount; ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Clubs Created
                        <span class="badge bg-success rounded-pill"><?php echo $clubsCreatedCount; ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Upcoming Events
                        <span class="badge bg-info rounded-pill"><?php echo $upcomingEventsCount; ?></span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Update Profile</h5>
            </div>
            <div class="card-body">
                <?php if (isset($errors) && !empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="needs-validation" novalidate>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="first_name" class="form-label">First Name</label>
                            <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo htmlspecialchars($user['first_name']); ?>" required>
                            <div class="invalid-feedback">Please enter your first name.</div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="last_name" class="form-label">Last Name</label>
                            <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo htmlspecialchars($user['last_name']); ?>" required>
                            <div class="invalid-feedback">Please enter your last name.</div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" readonly disabled>
                        <small class="form-text text-muted">Email address cannot be changed.</small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="mobile_no" class="form-label">Mobile Number</label>
                        <input type="tel" class="form-control" id="mobile_no" name="mobile_no" value="<?php echo htmlspecialchars($user['mobile_no'] ?? ''); ?>">
                    </div>
                    
                    <div class="d-grid gap-2">
                        <input type="hidden" name="update_profile" value="1">
                        <button type="submit" class="btn btn-primary">Update Profile</button>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Change Password</h5>
            </div>
            <div class="card-body">
                <?php if (isset($passwordErrors) && !empty($passwordErrors)): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($passwordErrors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="needs-validation" novalidate>
                    <div class="mb-3">
                        <label for="current_password" class="form-label">Current Password</label>
                        <input type="password" class="form-control" id="current_password" name="current_password" required>
                        <div class="invalid-feedback">Please enter your current password.</div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="new_password" class="form-label">New Password</label>
                            <input type="password" class="form-control" id="new_password" name="new_password" required minlength="8">
                            <div class="invalid-feedback">Password must be at least 8 characters long.</div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                            <div class="invalid-feedback">Please confirm your new password.</div>
                        </div>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <input type="hidden" name="change_password" value="1">
                        <button type="submit" class="btn btn-warning">Change Password</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include __DIR__ . '/../partials/footer.php';
?> 
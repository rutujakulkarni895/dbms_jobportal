<?php
/**
 * Events Page
 */

// Include configuration
require_once __DIR__ . '/../config/config.php';

// Redirect if not logged in
if (!isLoggedIn()) {
    setFlashMessage('error', 'You must be logged in to view events.');
    redirect(BASE_URL . '/pages/login.php');
}

$userId = getCurrentUserId();

// Get filter parameters
$clubId = isset($_GET['club_id']) ? (int)$_GET['club_id'] : null;
$status = isset($_GET['status']) ? cleanInput($_GET['status']) : 'upcoming';
$period = isset($_GET['period']) ? cleanInput($_GET['period']) : 'all';

// Get user clubs for filter dropdown
$userClubs = getUserClubs($userId);

// Get events based on filters
$conn = getDBConnection();

$whereClause = [];
$params = [];
$types = "";

// Base query to get events for clubs the user is a member of
$sql = "
    SELECT e.*, c.club_name
    FROM events e
    JOIN clubs c ON e.club_id = c.club_id
    JOIN club_members cm ON e.club_id = cm.club_id AND cm.user_id = ?
";

$types .= "i";
$params[] = $userId;

$whereClause[] = "1=1"; // Default condition to simplify concatenation

// Filter by club
if ($clubId) {
    $whereClause[] = "e.club_id = ?";
    $types .= "i";
    $params[] = $clubId;
}

// Filter by status
if ($status) {
    $whereClause[] = "e.status = ?";
    $types .= "s";
    $params[] = $status;
}

// Filter by time period
if ($period == 'upcoming') {
    $whereClause[] = "e.event_date > NOW()";
} elseif ($period == 'past') {
    $whereClause[] = "e.event_date < NOW()";
} elseif ($period == 'today') {
    $whereClause[] = "DATE(e.event_date) = CURDATE()";
} elseif ($period == 'week') {
    $whereClause[] = "e.event_date BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)";
} elseif ($period == 'month') {
    $whereClause[] = "e.event_date BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 1 MONTH)";
}

// Combine all where clauses
$sql .= " WHERE " . implode(" AND ", $whereClause);

// Add ordering
$sql .= " ORDER BY e.event_date";

// Prepare and execute the statement
$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

$events = [];
while ($row = $result->fetch_assoc()) {
    $events[] = $row;
}

// Include header
include __DIR__ . '/../partials/header.php';
?>

<div class="row mb-4">
    <div class="col-md-8">
        <h1>Events</h1>
        <p class="lead">View and manage events for your clubs.</p>
    </div>
</div>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="row g-3">
            <div class="col-md-3">
                <label for="club_id" class="form-label">Club</label>
                <select class="form-select" id="club_id" name="club_id">
                    <option value="">All Clubs</option>
                    <?php foreach ($userClubs as $club): ?>
                        <option value="<?php echo $club['club_id']; ?>" <?php echo ($clubId == $club['club_id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($club['club_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="upcoming" <?php echo ($status == 'upcoming') ? 'selected' : ''; ?>>Upcoming</option>
                    <option value="ongoing" <?php echo ($status == 'ongoing') ? 'selected' : ''; ?>>Ongoing</option>
                    <option value="completed" <?php echo ($status == 'completed') ? 'selected' : ''; ?>>Completed</option>
                    <option value="cancelled" <?php echo ($status == 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                    <option value="" <?php echo ($status === '') ? 'selected' : ''; ?>>All Statuses</option>
                </select>
            </div>
            
            <div class="col-md-3">
                <label for="period" class="form-label">Time Period</label>
                <select class="form-select" id="period" name="period">
                    <option value="all" <?php echo ($period == 'all') ? 'selected' : ''; ?>>All Time</option>
                    <option value="upcoming" <?php echo ($period == 'upcoming') ? 'selected' : ''; ?>>Upcoming</option>
                    <option value="past" <?php echo ($period == 'past') ? 'selected' : ''; ?>>Past</option>
                    <option value="today" <?php echo ($period == 'today') ? 'selected' : ''; ?>>Today</option>
                    <option value="week" <?php echo ($period == 'week') ? 'selected' : ''; ?>>Next 7 Days</option>
                    <option value="month" <?php echo ($period == 'month') ? 'selected' : ''; ?>>Next 30 Days</option>
                </select>
            </div>
            
            <div class="col-md-3 d-flex align-items-end">
                <button type="submit" class="btn btn-primary me-2">Filter</button>
                <a href="<?php echo BASE_URL; ?>/pages/events.php" class="btn btn-outline-secondary">Reset</a>
            </div>
        </form>
    </div>
</div>

<!-- Events List -->
<?php if (empty($events)): ?>
    <div class="alert alert-info">
        <p>No events found matching your criteria.</p>
    </div>
<?php else: ?>
    <div class="row">
        <?php foreach ($events as $event): ?>
            <?php 
            $isPast = strtotime($event['event_date']) < time();
            $statusClass = '';
            switch ($event['status']) {
                case 'upcoming':
                    $statusClass = 'bg-primary';
                    break;
                case 'ongoing':
                    $statusClass = 'bg-success';
                    break;
                case 'completed':
                    $statusClass = 'bg-secondary';
                    break;
                case 'cancelled':
                    $statusClass = 'bg-danger';
                    break;
            }
            ?>
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="card h-100 event-card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><?php echo htmlspecialchars($event['event_name']); ?></h5>
                        <span class="badge <?php echo $statusClass; ?>"><?php echo ucfirst($event['status']); ?></span>
                    </div>
                    <div class="card-body">
                        <p class="event-date">
                            <i class="far fa-calendar-alt me-2"></i>
                            <?php echo formatDateTime($event['event_date']); ?>
                        </p>
                        <p class="event-location">
                            <i class="fas fa-map-marker-alt me-2"></i>
                            <?php echo htmlspecialchars($event['location'] ?: 'No location specified'); ?>
                        </p>
                        <p class="club-name text-muted">
                            <i class="fas fa-users me-2"></i>
                            <?php echo htmlspecialchars($event['club_name']); ?>
                        </p>
                        <p class="event-description">
                            <?php echo htmlspecialchars(substr($event['description'], 0, 100)) . (strlen($event['description']) > 100 ? '...' : ''); ?>
                        </p>
                    </div>
                    <div class="card-footer bg-white">
                        <a href="<?php echo BASE_URL; ?>/pages/event_details.php?id=<?php echo $event['event_id']; ?>" class="btn btn-sm btn-outline-primary w-100">View Details</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<!-- Create Event CTA -->
<div class="text-center mt-4">
    <p>Can't find what you're looking for?</p>
    <a href="<?php echo BASE_URL; ?>/pages/create_event.php" class="btn btn-success"><i class="fas fa-plus-circle me-2"></i> Create New Event</a>
</div>

<?php
// Include footer
include __DIR__ . '/../partials/footer.php';
?> 
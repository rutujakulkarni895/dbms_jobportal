<?php
/**
 * Update Event Status Page
 * Allows club admins/moderators to update the status of an event
 */

// Include configuration
require_once __DIR__ . '/../config/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    setFlashMessage('error', 'You must be logged in to update an event status.');
    redirect(BASE_URL . '/pages/login.php');
}

// Check if event ID and status are provided
if (!isset($_GET['id']) || empty($_GET['id']) || !isset($_GET['status']) || empty($_GET['status'])) {
    setFlashMessage('error', 'Event ID and status are required.');
    redirect(BASE_URL . '/pages/events.php');
}

$eventId = (int)$_GET['id'];
$status = cleanInput($_GET['status']);
$userId = getCurrentUserId();

// Validate status
$validStatuses = ['upcoming', 'ongoing', 'completed', 'cancelled'];
if (!in_array($status, $validStatuses)) {
    setFlashMessage('error', 'Invalid event status.');
    redirect(BASE_URL . '/pages/event_details.php?id=' . $eventId);
}

// Get event details
$conn = getDBConnection();
$stmt = $conn->prepare("
    SELECT e.*, c.club_id
    FROM events e
    JOIN clubs c ON e.club_id = c.club_id
    WHERE e.event_id = ?
");
$stmt->bind_param("i", $eventId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    setFlashMessage('error', 'Event not found.');
    redirect(BASE_URL . '/pages/events.php');
}

$event = $result->fetch_assoc();
$clubId = $event['club_id'];

// Check if user is an admin or moderator of this club, or the event creator
$stmt = $conn->prepare("
    SELECT cm.role
    FROM club_members cm
    WHERE cm.club_id = ? AND cm.user_id = ? AND (cm.role IN ('admin', 'moderator') OR ? = ?)
");
$createdBy = $event['created_by'];
$stmt->bind_param("iiii", $clubId, $userId, $userId, $createdBy);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    setFlashMessage('error', 'You do not have permission to update this event.');
    redirect(BASE_URL . '/pages/event_details.php?id=' . $eventId);
}

// Update event status
$stmt = $conn->prepare("
    UPDATE events 
    SET status = ?
    WHERE event_id = ?
");
$stmt->bind_param("si", $status, $eventId);

if ($stmt->execute()) {
    // Set appropriate success message based on status
    $message = '';
    switch ($status) {
        case 'upcoming':
            $message = 'Event marked as upcoming.';
            break;
        case 'ongoing':
            $message = 'Event marked as ongoing.';
            break;
        case 'completed':
            $message = 'Event marked as completed.';
            break;
        case 'cancelled':
            $message = 'Event has been cancelled.';
            break;
    }
    
    setFlashMessage('success', $message);
} else {
    setFlashMessage('error', 'Failed to update event status: ' . $conn->error);
}

// Redirect back to event details
redirect(BASE_URL . '/pages/event_details.php?id=' . $eventId);
?> 
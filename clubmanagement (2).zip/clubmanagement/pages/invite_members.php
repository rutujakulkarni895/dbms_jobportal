<?php
/**
 * Invite Members Page
 * Allows club admins/moderators to invite users to join a club
 */

// Include configuration
require_once __DIR__ . '/../config/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    setFlashMessage('error', 'You must be logged in to invite members.');
    redirect(BASE_URL . '/pages/login.php');
}

// Check if club ID is provided
if (!isset($_GET['club_id']) || empty($_GET['club_id'])) {
    setFlashMessage('error', 'Club ID is required.');
    redirect(BASE_URL . '/pages/my_clubs.php');
}

$clubId = (int)$_GET['club_id'];
$userId = getCurrentUserId();

// Get club details
$club = getClubById($clubId);

if (!$club) {
    setFlashMessage('error', 'Club not found.');
    redirect(BASE_URL . '/pages/my_clubs.php');
}

// Check if user is an admin or moderator of this club
$conn = getDBConnection();
$stmt = $conn->prepare("
    SELECT role
    FROM club_members
    WHERE club_id = ? AND user_id = ? AND role IN ('admin', 'moderator')
");
$stmt->bind_param("ii", $clubId, $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    setFlashMessage('error', 'You do not have permission to invite members to this club.');
    redirect(BASE_URL . '/pages/club_details.php?id=' . $clubId);
}

$userRole = $result->fetch_assoc()['role'];

// Handle form submission - send invitations
if (isset($_POST['invite_members'])) {
    $emails = isset($_POST['emails']) ? explode(',', $_POST['emails']) : [];
    $message = cleanInput($_POST['message']);
    $successCount = 0;
    $errorCount = 0;
    
    foreach ($emails as $email) {
        $email = trim($email);
        
        // Skip empty emails
        if (empty($email)) {
            continue;
        }
        
        // Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            setFlashMessage('error', "Invalid email format: {$email}");
            $errorCount++;
            continue;
        }
        
        // Check if user exists
        $stmt = $conn->prepare("SELECT user_id, first_name, last_name FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            setFlashMessage('error', "User with email {$email} does not exist.");
            $errorCount++;
            continue;
        }
        
        $targetUser = $result->fetch_assoc();
        $targetUserId = $targetUser['user_id'];
        
        // Check if user is already a member
        $stmt = $conn->prepare("
            SELECT member_id FROM club_members 
            WHERE club_id = ? AND user_id = ?
        ");
        $stmt->bind_param("ii", $clubId, $targetUserId);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows > 0) {
            setFlashMessage('error', "{$email} is already a member of this club.");
            $errorCount++;
            continue;
        }
        
        // Check if there's already a pending invitation
        $stmt = $conn->prepare("
            SELECT req_id FROM membership_requests 
            WHERE club_id = ? AND user_id = ? AND status = 'pending'
        ");
        $stmt->bind_param("ii", $clubId, $targetUserId);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows > 0) {
            setFlashMessage('error', "There is already a pending invitation for {$email}.");
            $errorCount++;
            continue;
        }
        
        // Create invitation (membership request)
        $stmt = $conn->prepare("
            INSERT INTO membership_requests (user_id, club_id, status, invited_by) 
            VALUES (?, ?, 'pending', ?)
        ");
        $stmt->bind_param("iii", $targetUserId, $clubId, $userId);
        
        if ($stmt->execute()) {
            // Invitation created successfully
            $successCount++;
            
            // Optional: Send an email notification
            // sendInvitationEmail($email, $club['club_name'], $message);
        } else {
            setFlashMessage('error', "Failed to invite {$email}: " . $conn->error);
            $errorCount++;
        }
    }
    
    if ($successCount > 0) {
        setFlashMessage('success', "Successfully sent {$successCount} invitation(s).");
    }
    
    if ($errorCount > 0) {
        setFlashMessage('error', "Failed to send {$errorCount} invitation(s). See details above.");
    }
    
    // Redirect to avoid form resubmission
    redirect(BASE_URL . '/pages/invite_members.php?club_id=' . $clubId);
}

// Get user search results if search term is provided
$searchResults = [];
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchTerm = '%' . cleanInput($_GET['search']) . '%';
    
    $stmt = $conn->prepare("
        SELECT u.user_id, u.first_name, u.last_name, u.email,
               CASE WHEN cm.member_id IS NOT NULL THEN 1 ELSE 0 END AS is_member,
               CASE WHEN mr.req_id IS NOT NULL AND mr.status = 'pending' THEN 1 ELSE 0 END AS has_pending_request
        FROM users u
        LEFT JOIN club_members cm ON u.user_id = cm.user_id AND cm.club_id = ?
        LEFT JOIN membership_requests mr ON u.user_id = mr.user_id AND mr.club_id = ? AND mr.status = 'pending'
        WHERE (u.first_name LIKE ? OR u.last_name LIKE ? OR u.email LIKE ?)
        ORDER BY is_member ASC, u.first_name, u.last_name
        LIMIT 50
    ");
    $stmt->bind_param("iisss", $clubId, $clubId, $searchTerm, $searchTerm, $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $searchResults[] = $row;
    }
}

// Include header
include __DIR__ . '/../partials/header.php';
?>

<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1>Invite Members to <?php echo htmlspecialchars($club['club_name']); ?></h1>
            <p class="lead">Invite users to join your club by email or by searching for them.</p>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo BASE_URL; ?>/pages/manage_club.php?id=<?php echo $clubId; ?>&tab=members" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Back to Members
            </a>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-6">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-envelope me-2"></i> Invite by Email</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>?club_id=<?php echo $clubId; ?>">
                        <div class="mb-3">
                            <label for="emails" class="form-label">Email Addresses</label>
                            <textarea class="form-control" id="emails" name="emails" rows="3" placeholder="Enter email addresses, separated by commas" required></textarea>
                            <div class="form-text">Enter multiple email addresses separated by commas.</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="message" class="form-label">Optional Message</label>
                            <textarea class="form-control" id="message" name="message" rows="3" placeholder="Add a personal message (optional)"></textarea>
                        </div>
                        
                        <input type="hidden" name="invite_members" value="1">
                        <button type="submit" class="btn btn-primary">Send Invitations</button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-6">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-search me-2"></i> Search Users</h5>
                </div>
                <div class="card-body">
                    <form method="GET" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="mb-4">
                        <input type="hidden" name="club_id" value="<?php echo $clubId; ?>">
                        
                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Search by name or email" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>" required>
                            <button class="btn btn-outline-secondary" type="submit">Search</button>
                        </div>
                    </form>
                    
                    <?php if (!empty($searchResults)): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($searchResults as $user): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></td>
                                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                                            <td>
                                                <?php if ($user['is_member']): ?>
                                                    <span class="badge bg-success">Already a member</span>
                                                <?php elseif ($user['has_pending_request']): ?>
                                                    <span class="badge bg-warning text-dark">Pending invitation</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">Not a member</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if (!$user['is_member'] && !$user['has_pending_request']): ?>
                                                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>?club_id=<?php echo $clubId; ?>">
                                                        <input type="hidden" name="emails" value="<?php echo htmlspecialchars($user['email']); ?>">
                                                        <input type="hidden" name="invite_members" value="1">
                                                        <button type="submit" class="btn btn-sm btn-outline-primary">Send Invitation</button>
                                                    </form>
                                                <?php elseif ($user['has_pending_request']): ?>
                                                    <button class="btn btn-sm btn-outline-secondary" disabled>Invitation Sent</button>
                                                <?php else: ?>
                                                    <button class="btn btn-sm btn-outline-secondary" disabled>Already a Member</button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <?php if (count($searchResults) >= 50): ?>
                            <div class="alert alert-info mt-3">
                                <p class="mb-0">Showing the first 50 results. Please refine your search if you don't see the user you're looking for.</p>
                            </div>
                        <?php endif; ?>
                    <?php elseif (isset($_GET['search'])): ?>
                        <div class="alert alert-info">
                            <p class="mb-0">No users found matching '<?php echo htmlspecialchars($_GET['search']); ?>'. Try a different search term.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i> Tips for Inviting Members</h5>
                </div>
                <div class="card-body">
                    <ul>
                        <li>Invitations will appear in the user's notifications or dashboard.</li>
                        <li>Users must accept invitations before they become members.</li>
                        <li>Only invite people you know are interested in joining the club.</li>
                        <li>Adding a personal message increases the likelihood that people will accept your invitation.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include __DIR__ . '/../partials/footer.php';
?> 
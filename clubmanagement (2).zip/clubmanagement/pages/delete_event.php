<?php
/**
 * Delete Event Page
 * Allows club admins/moderators to delete an event
 */

// Include configuration
require_once __DIR__ . '/../config/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    setFlashMessage('error', 'You must be logged in to delete an event.');
    redirect(BASE_URL . '/pages/login.php');
}

// Check if event ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    setFlashMessage('error', 'Event ID is required.');
    redirect(BASE_URL . '/pages/events.php');
}

$eventId = (int)$_GET['id'];
$userId = getCurrentUserId();

// Get event details
$conn = getDBConnection();
$stmt = $conn->prepare("
    SELECT e.*, c.club_id, c.club_name
    FROM events e
    JOIN clubs c ON e.club_id = c.club_id
    WHERE e.event_id = ?
");
$stmt->bind_param("i", $eventId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    setFlashMessage('error', 'Event not found.');
    redirect(BASE_URL . '/pages/events.php');
}

$event = $result->fetch_assoc();
$clubId = $event['club_id'];
$clubName = $event['club_name'];

// Check if user is an admin or moderator of this club, or the event creator
$stmt = $conn->prepare("
    SELECT cm.role
    FROM club_members cm
    WHERE cm.club_id = ? AND cm.user_id = ? AND (cm.role IN ('admin', 'moderator') OR ? = ?)
");
$createdBy = $event['created_by'];
$stmt->bind_param("iiii", $clubId, $userId, $userId, $createdBy);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    setFlashMessage('error', 'You do not have permission to delete this event.');
    redirect(BASE_URL . '/pages/event_details.php?id=' . $eventId);
}

// Delete the event
$stmt = $conn->prepare("DELETE FROM events WHERE event_id = ?");
$stmt->bind_param("i", $eventId);

if ($stmt->execute()) {
    setFlashMessage('success', 'Event "' . htmlspecialchars($event['event_name']) . '" has been deleted successfully.');
    redirect(BASE_URL . '/pages/club_details.php?id=' . $clubId);
} else {
    setFlashMessage('error', 'Failed to delete event: ' . $conn->error);
    redirect(BASE_URL . '/pages/event_details.php?id=' . $eventId);
}
?> 
<div class="row">
    <div class="col-md-12 mb-4">
        <h1>Dashboard</h1>
        <p class="lead">Welcome back, <?php echo $_SESSION['first_name']; ?>!</p>
    </div>
</div>

<div class="row mb-4">
    <?php 
    // Get counts for various stats
    $userId = getCurrentUserId();
    $conn = getDBConnection();
    
    // Club count
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM club_members WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $clubCount = $stmt->get_result()->fetch_assoc()['count'];
    
    // Pending requests count
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM membership_requests WHERE user_id = ? AND status = 'pending'");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $pendingCount = $stmt->get_result()->fetch_assoc()['count'];
    
    // Upcoming events count
    $stmt = $conn->prepare("
        SELECT COUNT(*) as count 
        FROM events e
        JOIN club_members cm ON e.club_id = cm.club_id
        WHERE cm.user_id = ? AND e.status = 'upcoming' AND e.event_date > NOW()
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $eventCount = $stmt->get_result()->fetch_assoc()['count'];
    ?>
    
    <div class="col-md-4">
        <div class="dashboard-stats">
            <i class="fas fa-users fa-3x text-primary mb-3"></i>
            <div class="stat-value"><?php echo $clubCount; ?></div>
            <div class="stat-label">Clubs Joined</div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="dashboard-stats">
            <i class="fas fa-clock fa-3x text-warning mb-3"></i>
            <div class="stat-value"><?php echo $pendingCount; ?></div>
            <div class="stat-label">Pending Requests</div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="dashboard-stats">
            <i class="fas fa-calendar-alt fa-3x text-success mb-3"></i>
            <div class="stat-value"><?php echo $eventCount; ?></div>
            <div class="stat-label">Upcoming Events</div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Your Clubs</h5>
                <a href="<?php echo BASE_URL; ?>/pages/clubs.php" class="btn btn-sm btn-primary">Explore More Clubs</a>
            </div>
            <div class="card-body">
                <?php if (empty($userClubs)): ?>
                    <div class="alert alert-info">
                        <p>You haven't joined any clubs yet.</p>
                        <a href="<?php echo BASE_URL; ?>/pages/clubs.php" class="btn btn-primary mt-2">Explore Clubs</a>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <?php foreach(array_slice($userClubs, 0, 4) as $club): ?>
                            <div class="col-md-6 mb-3">
                                <div class="card h-100 club-card">
                                    <div class="card-body">
                                        <h5 class="club-name"><?php echo htmlspecialchars($club['club_name']); ?></h5>
                                        <p class="club-description"><?php echo htmlspecialchars(substr($club['description'], 0, 100)) . '...'; ?></p>
                                        <p class="club-stats text-muted">
                                            <span class="badge bg-secondary me-2"><?php echo $club['member_role']; ?></span>
                                        </p>
                                    </div>
                                    <div class="card-footer bg-white">
                                        <a href="<?php echo BASE_URL; ?>/pages/club_details.php?id=<?php echo $club['club_id']; ?>" class="btn btn-sm btn-outline-primary">View Club</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if (count($userClubs) > 4): ?>
                        <div class="text-center mt-3">
                            <a href="<?php echo BASE_URL; ?>/pages/my_clubs.php" class="btn btn-outline-primary">View All My Clubs</a>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Upcoming Events</h5>
                <a href="<?php echo BASE_URL; ?>/pages/events.php" class="btn btn-sm btn-primary">View All Events</a>
            </div>
            <div class="card-body">
                <?php if (empty($upcomingEvents)): ?>
                    <div class="alert alert-info">
                        <p>You have no upcoming events.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Event</th>
                                    <th>Club</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach(array_slice($upcomingEvents, 0, 5) as $event): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($event['event_name']); ?></td>
                                        <td><?php echo htmlspecialchars($event['club_name']); ?></td>
                                        <td><?php echo formatDateTime($event['event_date']); ?></td>
                                        <td>
                                            <span class="badge bg-info">Upcoming</span>
                                        </td>
                                        <td>
                                            <a href="<?php echo BASE_URL; ?>/pages/event_details.php?id=<?php echo $event['event_id']; ?>" class="btn btn-sm btn-outline-primary">Details</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Quick Actions</h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?php echo BASE_URL; ?>/pages/clubs.php" class="btn btn-outline-primary">Explore Clubs</a>
                    <a href="<?php echo BASE_URL; ?>/pages/create_club.php" class="btn btn-outline-success">Create a Club</a>
                    <a href="<?php echo BASE_URL; ?>/pages/profile.php" class="btn btn-outline-secondary">Update Profile</a>
                </div>
            </div>
        </div>
        
        <?php 
        // Get pending membership requests
        $stmt = $conn->prepare("
            SELECT mr.*, c.club_name
            FROM membership_requests mr
            JOIN clubs c ON mr.club_id = c.club_id
            WHERE mr.user_id = ? AND mr.status = 'pending'
            ORDER BY mr.request_date DESC
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $pendingRequests = [];
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $pendingRequests[] = $row;
        }
        ?>
        
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    Your Pending Requests
                    <?php if (count($pendingRequests) > 0): ?>
                        <span class="badge bg-warning float-end"><?php echo count($pendingRequests); ?></span>
                    <?php endif; ?>
                </h5>
            </div>
            <div class="card-body">
                <?php if (empty($pendingRequests)): ?>
                    <p class="text-muted">You have no pending club membership requests.</p>
                <?php else: ?>
                    <ul class="list-group">
                        <?php foreach ($pendingRequests as $request): ?>
                            <li class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong><?php echo htmlspecialchars($request['club_name']); ?></strong>
                                        <div class="text-muted small">Requested: <?php echo formatDateTime($request['request_date'], 'M d, Y'); ?></div>
                                    </div>
                                    <span class="badge badge-pending">Pending</span>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div> 
<?php
/**
 * Clubs Page
 */

// Include configuration
require_once __DIR__ . '/../config/config.php';

// Get search parameters
$search = isset($_GET['search']) ? cleanInput($_GET['search']) : '';

// Process join request
if (isLoggedIn() && isset($_POST['join_club']) && isset($_POST['club_id'])) {
    $clubId = (int)$_POST['club_id'];
    
    $result = requestClubMembership(getCurrentUserId(), $clubId);
    
    if ($result['success']) {
        setFlashMessage('success', $result['message']);
    } else {
        setFlashMessage('error', $result['message']);
    }
    
    // Redirect to avoid form resubmission
    redirect(BASE_URL . '/pages/clubs.php' . ($search ? "?search={$search}" : ''));
}

// Get all clubs
$clubs = getAllClubs();

// Filter clubs by search term
if (!empty($search)) {
    $filteredClubs = [];
    foreach ($clubs as $club) {
        if (stripos($club['club_name'], $search) !== false || stripos($club['description'], $search) !== false) {
            $filteredClubs[] = $club;
        }
    }
    $clubs = $filteredClubs;
}

// Check if user is already a member of clubs
$userClubs = [];
if (isLoggedIn()) {
    $userClubs = getUserClubs(getCurrentUserId());
    $userClubIds = array_column($userClubs, 'club_id');
    
    // Check for pending requests
    $userId = getCurrentUserId();
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT club_id FROM membership_requests WHERE user_id = ? AND status = 'pending'");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $pendingRequests = [];
    while ($row = $result->fetch_assoc()) {
        $pendingRequests[] = $row['club_id'];
    }
}

// Include header
include __DIR__ . '/../partials/header.php';
?>

<div class="row mb-4">
    <div class="col-md-8">
        <h1>Explore Clubs</h1>
        <p class="lead">Discover and join clubs based on your interests.</p>
    </div>
    <div class="col-md-4 text-end">
        <?php if (isLoggedIn()): ?>
            <a href="<?php echo BASE_URL; ?>/pages/create_club.php" class="btn btn-success"><i class="fas fa-plus-circle me-2"></i> Create Club</a>
        <?php endif; ?>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-12">
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="GET" class="d-flex">
            <input type="text" name="search" class="form-control me-2" placeholder="Search clubs..." value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit" class="btn btn-primary">Search</button>
            <?php if ($search): ?>
                <a href="<?php echo BASE_URL; ?>/pages/clubs.php" class="btn btn-outline-secondary ms-2">Clear</a>
            <?php endif; ?>
        </form>
    </div>
</div>

<?php if (empty($clubs)): ?>
    <div class="alert alert-info">
        <?php if ($search): ?>
            <p>No clubs found matching "<?php echo htmlspecialchars($search); ?>". Try a different search term or <a href="<?php echo BASE_URL; ?>/pages/create_club.php">create your own club</a>.</p>
        <?php else: ?>
            <p>No clubs available yet. Be the first to <a href="<?php echo BASE_URL; ?>/pages/create_club.php">create a club</a>!</p>
        <?php endif; ?>
    </div>
<?php else: ?>
    <div class="row">
        <?php foreach ($clubs as $club): ?>
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="card h-100 club-card">
                    <div class="card-body">
                        <h5 class="club-name"><?php echo htmlspecialchars($club['club_name']); ?></h5>
                        <p class="club-description"><?php echo htmlspecialchars(substr($club['description'], 0, 150)) . (strlen($club['description']) > 150 ? '...' : ''); ?></p>
                        <div class="club-stats text-muted small">
                            <span><i class="fas fa-users me-1"></i> <?php echo $club['total_members']; ?> members</span>
                            <span class="ms-3"><i class="fas fa-calendar-alt me-1"></i> <?php echo $club['upcoming_events']; ?> upcoming events</span>
                        </div>
                    </div>
                    <div class="card-footer bg-white">
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="<?php echo BASE_URL; ?>/pages/club_details.php?id=<?php echo $club['club_id']; ?>" class="btn btn-sm btn-outline-primary">View Details</a>
                            
                            <?php if (isLoggedIn()): ?>
                                <?php if (in_array($club['club_id'], array_column($userClubs, 'club_id'))): ?>
                                    <span class="badge bg-success">Member</span>
                                <?php elseif (in_array($club['club_id'], $pendingRequests)): ?>
                                    <span class="badge bg-warning text-dark">Request Pending</span>
                                <?php else: ?>
                                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) . ($search ? "?search={$search}" : ''); ?>">
                                        <input type="hidden" name="club_id" value="<?php echo $club['club_id']; ?>">
                                        <input type="hidden" name="join_club" value="1">
                                        <button type="submit" class="btn btn-sm btn-primary">Join Club</button>
                                    </form>
                                <?php endif; ?>
                            <?php else: ?>
                                <a href="<?php echo BASE_URL; ?>/pages/login.php" class="btn btn-sm btn-outline-secondary">Login to Join</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php
// Include footer
include __DIR__ . '/../partials/footer.php';
?> 
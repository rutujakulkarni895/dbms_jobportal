<?php
/**
 * My Clubs Page
 */

// Include configuration
require_once __DIR__ . '/../config/config.php';

// Redirect if not logged in
if (!isLoggedIn()) {
    setFlashMessage('error', 'You must be logged in to view your clubs.');
    redirect(BASE_URL . '/pages/login.php');
}

$userId = getCurrentUserId();

// Get user clubs
$userClubs = getUserClubs($userId);

// Get pending requests
$conn = getDBConnection();
$stmt = $conn->prepare("
    SELECT mr.*, c.club_name, c.description
    FROM membership_requests mr
    JOIN clubs c ON mr.club_id = c.club_id
    WHERE mr.user_id = ? AND mr.status = 'pending'
    ORDER BY mr.request_date DESC
");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$pendingRequests = [];
while ($row = $result->fetch_assoc()) {
    $pendingRequests[] = $row;
}

// Get clubs created by the user
$stmt = $conn->prepare("
    SELECT c.*, 
           (SELECT COUNT(*) FROM club_members WHERE club_id = c.club_id) as total_members,
           (SELECT COUNT(*) FROM membership_requests WHERE club_id = c.club_id AND status = 'pending') as pending_requests,
           (SELECT COUNT(*) FROM events WHERE club_id = c.club_id AND status = 'upcoming') as upcoming_events
    FROM clubs c
    WHERE c.created_by = ?
    ORDER BY c.created_at DESC
");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$createdClubs = [];
while ($row = $result->fetch_assoc()) {
    $createdClubs[] = $row;
}

// Process leave club
if (isset($_POST['leave_club']) && isset($_POST['member_id'])) {
    $memberId = (int)$_POST['member_id'];
    
    // Check if user is trying to leave a club they created
    $stmt = $conn->prepare("
        SELECT cm.member_id, c.created_by, c.club_name, cm.role
        FROM club_members cm
        JOIN clubs c ON cm.club_id = c.club_id
        WHERE cm.member_id = ? AND cm.user_id = ?
    ");
    $stmt->bind_param("ii", $memberId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $memberInfo = $result->fetch_assoc();
        
        // Prevent leaving if user is the creator/admin
        if ($memberInfo['created_by'] == $userId && $memberInfo['role'] == 'admin') {
            setFlashMessage('error', 'You cannot leave a club you created. Transfer ownership first or delete the club.');
        } else {
            // Remove the member
            $stmt = $conn->prepare("DELETE FROM club_members WHERE member_id = ? AND user_id = ?");
            $stmt->bind_param("ii", $memberId, $userId);
            
            if ($stmt->execute()) {
                setFlashMessage('success', 'You have left the club successfully.');
                
                // Refresh user clubs
                $userClubs = getUserClubs($userId);
            } else {
                setFlashMessage('error', 'Failed to leave the club: ' . $conn->error);
            }
        }
    } else {
        setFlashMessage('error', 'Invalid request.');
    }
}

// Include header
include __DIR__ . '/../partials/header.php';
?>

<div class="row mb-4">
    <div class="col-md-8">
        <h1>My Clubs</h1>
        <p class="lead">Clubs you've joined, created, and your pending requests.</p>
    </div>
    <div class="col-md-4 text-end">
        <a href="<?php echo BASE_URL; ?>/pages/create_club.php" class="btn btn-success"><i class="fas fa-plus-circle me-2"></i> Create Club</a>
        <a href="<?php echo BASE_URL; ?>/pages/clubs.php" class="btn btn-primary"><i class="fas fa-search me-2"></i> Find Clubs</a>
    </div>
</div>

<!-- Clubs I'm In -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">Clubs I'm In (<?php echo count($userClubs); ?>)</h5>
    </div>
    <div class="card-body">
        <?php if (empty($userClubs)): ?>
            <div class="alert alert-info">
                <p>You haven't joined any clubs yet.</p>
                <a href="<?php echo BASE_URL; ?>/pages/clubs.php" class="btn btn-primary mt-2">Explore Clubs</a>
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($userClubs as $club): ?>
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card h-100 club-card">
                            <div class="card-body">
                                <h5 class="club-name"><?php echo htmlspecialchars($club['club_name']); ?></h5>
                                <p class="club-description"><?php echo htmlspecialchars(substr($club['description'], 0, 100)) . '...'; ?></p>
                                <p class="club-stats text-muted">
                                    <span class="badge <?php echo ($club['member_role'] == 'admin') ? 'bg-danger' : (($club['member_role'] == 'moderator') ? 'bg-warning text-dark' : 'bg-secondary'); ?> me-2">
                                        <?php echo ucfirst($club['member_role']); ?>
                                    </span>
                                </p>
                            </div>
                            <div class="card-footer bg-white">
                                <div class="d-flex justify-content-between align-items-center">
                                    <a href="<?php echo BASE_URL; ?>/pages/club_details.php?id=<?php echo $club['club_id']; ?>" class="btn btn-sm btn-outline-primary">View Club</a>
                                    
                                    <?php if ($club['member_role'] != 'admin'): ?>
                                        <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" onsubmit="return confirm('Are you sure you want to leave this club?');">
                                            <input type="hidden" name="member_id" value="<?php echo $club['member_id']; ?>">
                                            <input type="hidden" name="leave_club" value="1">
                                            <button type="submit" class="btn btn-sm btn-outline-danger">Leave</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Clubs I Created -->
<?php if (!empty($createdClubs)): ?>
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">Clubs I Created (<?php echo count($createdClubs); ?>)</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <?php foreach ($createdClubs as $club): ?>
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card h-100 club-card">
                            <div class="card-body">
                                <h5 class="club-name"><?php echo htmlspecialchars($club['club_name']); ?></h5>
                                <p class="club-description"><?php echo htmlspecialchars(substr($club['description'], 0, 100)) . '...'; ?></p>
                                <div class="club-stats text-muted small">
                                    <span><i class="fas fa-users me-1"></i> <?php echo $club['total_members']; ?> members</span>
                                    <?php if ($club['pending_requests'] > 0): ?>
                                        <span class="ms-3 text-warning"><i class="fas fa-clock me-1"></i> <?php echo $club['pending_requests']; ?> pending</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="card-footer bg-white">
                                <div class="d-flex justify-content-between align-items-center">
                                    <a href="<?php echo BASE_URL; ?>/pages/club_details.php?id=<?php echo $club['club_id']; ?>" class="btn btn-sm btn-outline-primary">View Club</a>
                                    <a href="<?php echo BASE_URL; ?>/pages/manage_club.php?id=<?php echo $club['club_id']; ?>" class="btn btn-sm btn-outline-success">Manage</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Pending Requests -->
<?php if (!empty($pendingRequests)): ?>
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Pending Requests (<?php echo count($pendingRequests); ?>)</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Club</th>
                            <th>Requested On</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pendingRequests as $request): ?>
                            <tr>
                                <td>
                                    <a href="<?php echo BASE_URL; ?>/pages/club_details.php?id=<?php echo $request['club_id']; ?>">
                                        <?php echo htmlspecialchars($request['club_name']); ?>
                                    </a>
                                </td>
                                <td><?php echo formatDateTime($request['request_date'], 'M d, Y'); ?></td>
                                <td><span class="badge badge-pending">Pending</span></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php
// Include footer
include __DIR__ . '/../partials/footer.php';
?> 
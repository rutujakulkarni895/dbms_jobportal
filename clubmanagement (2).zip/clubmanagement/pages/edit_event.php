<?php
/**
 * Edit Event Page
 * Allows club admins/moderators to edit existing events
 */

// Include configuration
require_once __DIR__ . '/../config/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    setFlashMessage('error', 'You must be logged in to edit an event.');
    redirect(BASE_URL . '/pages/login.php');
}

// Check if event ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    setFlashMessage('error', 'Event ID is required.');
    redirect(BASE_URL . '/pages/events.php');
}

$eventId = (int)$_GET['id'];
$userId = getCurrentUserId();

// Get event details
$conn = getDBConnection();
$stmt = $conn->prepare("
    SELECT e.*, c.club_name
    FROM events e
    JOIN clubs c ON e.club_id = c.club_id
    WHERE e.event_id = ?
");
$stmt->bind_param("i", $eventId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    setFlashMessage('error', 'Event not found.');
    redirect(BASE_URL . '/pages/events.php');
}

$event = $result->fetch_assoc();
$clubId = $event['club_id'];

// Check if user is an admin or moderator of this club, or the event creator
$stmt = $conn->prepare("
    SELECT cm.role
    FROM club_members cm
    WHERE cm.club_id = ? AND cm.user_id = ? AND (cm.role IN ('admin', 'moderator') OR ? = ?)
");
$createdBy = $event['created_by'];
$stmt->bind_param("iiii", $clubId, $userId, $userId, $createdBy);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    setFlashMessage('error', 'You do not have permission to edit this event.');
    redirect(BASE_URL . '/pages/event_details.php?id=' . $eventId);
}

// Parse event date and time
$eventDateTime = new DateTime($event['event_date']);
$eventDate = $eventDateTime->format('Y-m-d');
$eventTime = $eventDateTime->format('H:i');

// Form processing
if (isset($_POST['update_event'])) {
    // Validate and sanitize inputs
    $eventName = cleanInput($_POST['event_name']);
    $description = cleanInput($_POST['description']);
    $location = cleanInput($_POST['location']);
    $eventDate = cleanInput($_POST['event_date']);
    $eventTime = cleanInput($_POST['event_time']);
    $status = cleanInput($_POST['status']);
    
    // Combine date and time
    $eventDateTime = $eventDate . ' ' . $eventTime . ':00';
    
    // Validate inputs
    $errors = [];
    
    if (empty($eventName)) {
        $errors[] = 'Event name is required.';
    }
    
    if (empty($description)) {
        $errors[] = 'Event description is required.';
    }
    
    if (empty($eventDate) || empty($eventTime)) {
        $errors[] = 'Event date and time are required.';
    } else {
        // Validate date format
        $dateTimestamp = strtotime($eventDateTime);
        
        if ($dateTimestamp === false) {
            $errors[] = 'Invalid date or time format.';
        }
    }
    
    // Validate status
    $validStatuses = ['upcoming', 'ongoing', 'completed', 'cancelled'];
    if (!in_array($status, $validStatuses)) {
        $errors[] = 'Invalid event status.';
    }
    
    // If no errors, update the event
    if (empty($errors)) {
        $stmt = $conn->prepare("
            UPDATE events 
            SET event_name = ?, description = ?, event_date = ?, location = ?, status = ?
            WHERE event_id = ?
        ");
        $stmt->bind_param("sssssi", $eventName, $description, $eventDateTime, $location, $status, $eventId);
        
        if ($stmt->execute()) {
            setFlashMessage('success', 'Event updated successfully!');
            redirect(BASE_URL . '/pages/event_details.php?id=' . $eventId);
        } else {
            setFlashMessage('error', 'Failed to update event: ' . $conn->error);
        }
    } else {
        // Set error messages
        foreach ($errors as $error) {
            setFlashMessage('error', $error);
        }
    }
}

// Include header
include __DIR__ . '/../partials/header.php';
?>

<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1>Edit Event</h1>
            <p class="lead">Update event details for <strong><?php echo htmlspecialchars($event['event_name']); ?></strong></p>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo BASE_URL; ?>/pages/event_details.php?id=<?php echo $eventId; ?>" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Back to Event
            </a>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Event Details</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) . '?id=' . $eventId; ?>">
                        <div class="mb-3">
                            <label for="club_name" class="form-label">Club</label>
                            <input type="text" class="form-control" id="club_name" value="<?php echo htmlspecialchars($event['club_name']); ?>" disabled>
                            <div class="form-text">The club cannot be changed. If needed, create a new event for a different club.</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="event_name" class="form-label">Event Name</label>
                            <input type="text" class="form-control" id="event_name" name="event_name" value="<?php echo htmlspecialchars($event['event_name']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="4" required><?php echo htmlspecialchars($event['description']); ?></textarea>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="event_date" class="form-label">Date</label>
                                <input type="date" class="form-control" id="event_date" name="event_date" value="<?php echo $eventDate; ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label for="event_time" class="form-label">Time</label>
                                <input type="time" class="form-control" id="event_time" name="event_time" value="<?php echo $eventTime; ?>" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="location" class="form-label">Location</label>
                            <input type="text" class="form-control" id="location" name="location" value="<?php echo htmlspecialchars($event['location'] ?? ''); ?>" placeholder="Enter venue, address, or online meeting link">
                        </div>
                        
                        <div class="mb-3">
                            <label for="status" class="form-label">Event Status</label>
                            <select class="form-select" id="status" name="status" required>
                                <option value="upcoming" <?php echo ($event['status'] === 'upcoming') ? 'selected' : ''; ?>>Upcoming</option>
                                <option value="ongoing" <?php echo ($event['status'] === 'ongoing') ? 'selected' : ''; ?>>Ongoing</option>
                                <option value="completed" <?php echo ($event['status'] === 'completed') ? 'selected' : ''; ?>>Completed</option>
                                <option value="cancelled" <?php echo ($event['status'] === 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                            </select>
                        </div>
                        
                        <input type="hidden" name="update_event" value="1">
                        <button type="submit" class="btn btn-primary">Update Event</button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Tips for Editing Events</h5>
                </div>
                <div class="card-body">
                    <ul class="mb-0">
                        <li class="mb-2">If you change the date or time, make sure to update the event description with any important changes.</li>
                        <li class="mb-2">Setting status to "cancelled" will indicate to club members that the event won't happen.</li>
                        <li class="mb-2">If you're changing important details (like location or date), highlight this in the description.</li>
                        <li class="mb-2">Make sure your description is clear and provides all necessary information for members.</li>
                    </ul>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Need to Delete?</h5>
                </div>
                <div class="card-body">
                    <p>If you need to completely delete this event instead of updating it:</p>
                    <a href="<?php echo BASE_URL; ?>/pages/delete_event.php?id=<?php echo $eventId; ?>" class="btn btn-danger w-100" onclick="return confirm('Are you sure you want to permanently delete this event? This action cannot be undone!');">
                        <i class="fas fa-trash-alt me-2"></i> Delete This Event
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include __DIR__ . '/../partials/footer.php';
?> 
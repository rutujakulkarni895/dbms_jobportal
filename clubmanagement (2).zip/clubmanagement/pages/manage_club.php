<?php
/**
 * Manage Club Page
 * Allows club admins/moderators to manage club settings, members, and requests
 */

// Include configuration
require_once __DIR__ . '/../config/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    setFlashMessage('error', 'You must be logged in to manage a club.');
    redirect(BASE_URL . '/pages/login.php');
}

// Check if club ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    setFlashMessage('error', 'Club ID is required.');
    redirect(BASE_URL . '/pages/my_clubs.php');
}

$clubId = (int)$_GET['id'];
$userId = getCurrentUserId();

// Get club details
$club = getClubById($clubId);

if (!$club) {
    setFlashMessage('error', 'Club not found.');
    redirect(BASE_URL . '/pages/my_clubs.php');
}

// Check if user is an admin or moderator of this club
$conn = getDBConnection();
$stmt = $conn->prepare("
    SELECT role
    FROM club_members
    WHERE club_id = ? AND user_id = ? AND role IN ('admin', 'moderator')
");
$stmt->bind_param("ii", $clubId, $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    setFlashMessage('error', 'You do not have permission to manage this club.');
    redirect(BASE_URL . '/pages/club_details.php?id=' . $clubId);
}

$userRole = $result->fetch_assoc()['role'];
$isAdmin = ($userRole === 'admin');

// Get active tab
$activeTab = isset($_GET['tab']) ? $_GET['tab'] : 'settings';
$validTabs = ['settings', 'members', 'requests', 'events'];
$activeTab = in_array($activeTab, $validTabs) ? $activeTab : 'settings';

// Process club update
if (isset($_POST['update_club']) && $isAdmin) {
    $clubName = cleanInput($_POST['club_name']);
    $description = cleanInput($_POST['description']);
    
    if (empty($clubName)) {
        setFlashMessage('error', 'Club name is required.');
    } else {
        $conn = getDBConnection();
        // Check if name is taken (except by current club)
        $stmt = $conn->prepare("
            SELECT club_id FROM clubs 
            WHERE club_name = ? AND club_id != ?
        ");
        $stmt->bind_param("si", $clubName, $clubId);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows > 0) {
            setFlashMessage('error', 'Club name is already taken.');
        } else {
            $stmt = $conn->prepare("
                UPDATE clubs 
                SET club_name = ?, description = ?
                WHERE club_id = ?
            ");
            $stmt->bind_param("ssi", $clubName, $description, $clubId);
            
            if ($stmt->execute()) {
                setFlashMessage('success', 'Club details updated successfully.');
                $club['club_name'] = $clubName;
                $club['description'] = $description;
            } else {
                setFlashMessage('error', 'Failed to update club: ' . $conn->error);
            }
        }
    }
}

// Process membership requests
if (isset($_POST['process_request'])) {
    $requestId = (int)$_POST['request_id'];
    $action = $_POST['action'];
    
    if (!in_array($action, ['approve', 'reject'])) {
        setFlashMessage('error', 'Invalid action.');
    } else {
        $status = ($action === 'approve') ? 'approved' : 'rejected';
        
        $conn = getDBConnection();
        
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Update request status
            $stmt = $conn->prepare("
                UPDATE membership_requests 
                SET status = ?, response_date = NOW() 
                WHERE req_id = ? AND club_id = ?
            ");
            $stmt->bind_param("sii", $status, $requestId, $clubId);
            $stmt->execute();
            
            // If approved, add member to club
            if ($action === 'approve') {
                // Get user ID from request
                $stmt = $conn->prepare("
                    SELECT user_id FROM membership_requests 
                    WHERE req_id = ?
                ");
                $stmt->bind_param("i", $requestId);
                $stmt->execute();
                $requestUserId = $stmt->get_result()->fetch_assoc()['user_id'];
                
                // Add as club member
                $memberRole = 'member';
                $stmt = $conn->prepare("
                    INSERT INTO club_members (user_id, club_id, role) 
                    VALUES (?, ?, ?)
                ");
                $stmt->bind_param("iis", $requestUserId, $clubId, $memberRole);
                $stmt->execute();
            }
            
            // Commit transaction
            $conn->commit();
            
            $message = ($action === 'approve') ? 'Membership request approved.' : 'Membership request rejected.';
            setFlashMessage('success', $message);
        } catch (Exception $e) {
            // Rollback on error
            $conn->rollback();
            setFlashMessage('error', 'Error processing request: ' . $e->getMessage());
        }
    }
    
    // Redirect to avoid form resubmission
    redirect(BASE_URL . '/pages/manage_club.php?id=' . $clubId . '&tab=requests');
}

// Process role change
if (isset($_POST['update_role']) && $isAdmin) {
    $memberId = (int)$_POST['member_id'];
    $newRole = cleanInput($_POST['role']);
    
    if (!in_array($newRole, ['member', 'moderator', 'admin'])) {
        setFlashMessage('error', 'Invalid role.');
    } else {
        $conn = getDBConnection();
        
        // Verify the member belongs to this club
        $stmt = $conn->prepare("
            SELECT cm.user_id, u.email
            FROM club_members cm
            JOIN users u ON cm.user_id = u.user_id
            WHERE cm.member_id = ? AND cm.club_id = ?
        ");
        $stmt->bind_param("ii", $memberId, $clubId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            setFlashMessage('error', 'Member not found.');
        } else {
            $memberInfo = $result->fetch_assoc();
            
            // Prevent demoting the club creator
            if ($memberInfo['user_id'] == $club['created_by'] && $newRole != 'admin') {
                setFlashMessage('error', 'Cannot change the role of the club creator.');
            } else {
                $stmt = $conn->prepare("
                    UPDATE club_members 
                    SET role = ?
                    WHERE member_id = ? AND club_id = ?
                ");
                $stmt->bind_param("sii", $newRole, $memberId, $clubId);
                
                if ($stmt->execute()) {
                    $message = 'Role updated for ' . $memberInfo['email'];
                    setFlashMessage('success', $message);
                } else {
                    setFlashMessage('error', 'Failed to update role: ' . $conn->error);
                }
            }
        }
    }
    
    // Redirect to avoid form resubmission
    redirect(BASE_URL . '/pages/manage_club.php?id=' . $clubId . '&tab=members');
}

// Process remove member
if (isset($_POST['remove_member']) && $isAdmin) {
    $memberId = (int)$_POST['member_id'];
    
    $conn = getDBConnection();
    
    // Verify the member belongs to this club and isn't the creator
    $stmt = $conn->prepare("
        SELECT cm.user_id, u.email
        FROM club_members cm
        JOIN users u ON cm.user_id = u.user_id
        WHERE cm.member_id = ? AND cm.club_id = ?
    ");
    $stmt->bind_param("ii", $memberId, $clubId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        setFlashMessage('error', 'Member not found.');
    } else {
        $memberInfo = $result->fetch_assoc();
        
        // Prevent removing the club creator
        if ($memberInfo['user_id'] == $club['created_by']) {
            setFlashMessage('error', 'Cannot remove the club creator.');
        } else {
            $stmt = $conn->prepare("DELETE FROM club_members WHERE member_id = ? AND club_id = ?");
            $stmt->bind_param("ii", $memberId, $clubId);
            
            if ($stmt->execute()) {
                $message = 'Removed ' . $memberInfo['email'] . ' from the club.';
                setFlashMessage('success', $message);
            } else {
                setFlashMessage('error', 'Failed to remove member: ' . $conn->error);
            }
        }
    }
    
    // Redirect to avoid form resubmission
    redirect(BASE_URL . '/pages/manage_club.php?id=' . $clubId . '&tab=members');
}

// Get membership requests
$requests = [];
if ($activeTab === 'requests') {
    $stmt = $conn->prepare("
        SELECT mr.*, u.first_name, u.last_name, u.email
        FROM membership_requests mr
        JOIN users u ON mr.user_id = u.user_id
        WHERE mr.club_id = ? AND mr.status = 'pending'
        ORDER BY mr.request_date
    ");
    $stmt->bind_param("i", $clubId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $requests[] = $row;
    }
}

// Get all members
$members = [];
if ($activeTab === 'members') {
    $stmt = $conn->prepare("
        SELECT cm.*, u.first_name, u.last_name, u.email
        FROM club_members cm
        JOIN users u ON cm.user_id = u.user_id
        WHERE cm.club_id = ?
        ORDER BY cm.role = 'admin' DESC, cm.role = 'moderator' DESC, u.first_name, u.last_name
    ");
    $stmt->bind_param("i", $clubId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $members[] = $row;
    }
}

// Get club events
$events = [];
if ($activeTab === 'events') {
    $stmt = $conn->prepare("
        SELECT * FROM events
        WHERE club_id = ?
        ORDER BY event_date DESC
    ");
    $stmt->bind_param("i", $clubId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $events[] = $row;
    }
}

// Include header
include __DIR__ . '/../partials/header.php';
?>

<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1>Manage Club: <?php echo htmlspecialchars($club['club_name']); ?></h1>
            <p class="text-muted">
                <i class="fas fa-user-shield me-2"></i> You are managing this club as <?php echo ucfirst($userRole); ?>
            </p>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo BASE_URL; ?>/pages/club_details.php?id=<?php echo $clubId; ?>" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Back to Club
            </a>
        </div>
    </div>
    
    <ul class="nav nav-tabs mb-4">
        <?php if ($isAdmin): ?>
        <li class="nav-item">
            <a class="nav-link <?php echo ($activeTab === 'settings') ? 'active' : ''; ?>" href="?id=<?php echo $clubId; ?>&tab=settings">
                <i class="fas fa-cog me-2"></i> Settings
            </a>
        </li>
        <?php endif; ?>
        
        <li class="nav-item">
            <a class="nav-link <?php echo ($activeTab === 'members') ? 'active' : ''; ?>" href="?id=<?php echo $clubId; ?>&tab=members">
                <i class="fas fa-users me-2"></i> Members <?php echo !empty($members) ? '(' . count($members) . ')' : ''; ?>
            </a>
        </li>
        
        <li class="nav-item">
            <a class="nav-link <?php echo ($activeTab === 'requests') ? 'active' : ''; ?>" href="?id=<?php echo $clubId; ?>&tab=requests">
                <i class="fas fa-user-plus me-2"></i> Requests 
                <?php if (!empty($requests)): ?>
                <span class="badge bg-warning text-dark"><?php echo count($requests); ?></span>
                <?php endif; ?>
            </a>
        </li>
        
        <li class="nav-item">
            <a class="nav-link <?php echo ($activeTab === 'events') ? 'active' : ''; ?>" href="?id=<?php echo $clubId; ?>&tab=events">
                <i class="fas fa-calendar-alt me-2"></i> Events
            </a>
        </li>
    </ul>
    
    <?php if ($activeTab === 'settings' && $isAdmin): ?>
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">Club Settings</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>?id=<?php echo $clubId; ?>&tab=settings">
                <div class="mb-3">
                    <label for="club_name" class="form-label">Club Name</label>
                    <input type="text" class="form-control" id="club_name" name="club_name" value="<?php echo htmlspecialchars($club['club_name']); ?>" required>
                </div>
                
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="4" required><?php echo htmlspecialchars($club['description']); ?></textarea>
                </div>
                
                <input type="hidden" name="update_club" value="1">
                <button type="submit" class="btn btn-primary">Update Club</button>
            </form>
        </div>
    </div>
    
    <div class="card mb-4 border-danger">
        <div class="card-header bg-danger text-white">
            <h5 class="mb-0">Danger Zone</h5>
        </div>
        <div class="card-body">
            <h6>Delete Club</h6>
            <p>Once you delete a club, there is no going back. Please be certain.</p>
            <a href="<?php echo BASE_URL; ?>/pages/delete_club.php?id=<?php echo $clubId; ?>" class="btn btn-outline-danger" onclick="return confirm('Are you sure you want to permanently delete this club? This action cannot be undone!');">
                Delete this club
            </a>
        </div>
    </div>
    <?php endif; ?>
    
    <?php if ($activeTab === 'members'): ?>
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Club Members</h5>
            <a href="<?php echo BASE_URL; ?>/pages/invite_members.php?club_id=<?php echo $clubId; ?>" class="btn btn-sm btn-primary">
                <i class="fas fa-user-plus me-2"></i> Invite Members
            </a>
        </div>
        <div class="card-body">
            <?php if (empty($members)): ?>
                <div class="alert alert-info">
                    <p class="mb-0">No members found.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Join Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($members as $member): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?></td>
                                    <td><?php echo htmlspecialchars($member['email']); ?></td>
                                    <td>
                                        <?php
                                        $roleBadge = 'bg-secondary';
                                        if ($member['role'] === 'admin') {
                                            $roleBadge = 'bg-danger';
                                        } elseif ($member['role'] === 'moderator') {
                                            $roleBadge = 'bg-warning text-dark';
                                        }
                                        ?>
                                        <span class="badge <?php echo $roleBadge; ?>"><?php echo ucfirst($member['role']); ?></span>
                                        
                                        <?php if ($member['user_id'] == $club['created_by']): ?>
                                            <span class="badge bg-info ms-1">Creator</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo formatDateTime($member['join_date'], 'M d, Y'); ?></td>
                                    <td>
                                        <?php if ($isAdmin && $member['user_id'] != $userId): ?>
                                            <div class="d-flex">
                                                <?php if ($member['user_id'] != $club['created_by']): ?>
                                                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>?id=<?php echo $clubId; ?>&tab=members" class="me-2">
                                                        <input type="hidden" name="member_id" value="<?php echo $member['member_id']; ?>">
                                                        <select name="role" class="form-select form-select-sm" onchange="this.form.submit()">
                                                            <option value="">Change Role</option>
                                                            <option value="member" <?php echo ($member['role'] === 'member') ? 'disabled' : ''; ?>>Member</option>
                                                            <option value="moderator" <?php echo ($member['role'] === 'moderator') ? 'disabled' : ''; ?>>Moderator</option>
                                                            <option value="admin" <?php echo ($member['role'] === 'admin') ? 'disabled' : ''; ?>>Admin</option>
                                                        </select>
                                                        <input type="hidden" name="update_role" value="1">
                                                    </form>
                                                    
                                                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>?id=<?php echo $clubId; ?>&tab=members" onsubmit="return confirm('Are you sure you want to remove this member from the club?');">
                                                        <input type="hidden" name="member_id" value="<?php echo $member['member_id']; ?>">
                                                        <input type="hidden" name="remove_member" value="1">
                                                        <button type="submit" class="btn btn-sm btn-outline-danger">Remove</button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
    
    <?php if ($activeTab === 'requests'): ?>
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">Membership Requests</h5>
        </div>
        <div class="card-body">
            <?php if (empty($requests)): ?>
                <div class="alert alert-info">
                    <p class="mb-0">No pending membership requests.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Requested</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($requests as $request): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($request['first_name'] . ' ' . $request['last_name']); ?></td>
                                    <td><?php echo htmlspecialchars($request['email']); ?></td>
                                    <td><?php echo formatDateTime($request['request_date']); ?></td>
                                    <td>
                                        <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>?id=<?php echo $clubId; ?>&tab=requests" class="d-flex">
                                            <input type="hidden" name="request_id" value="<?php echo $request['req_id']; ?>">
                                            <input type="hidden" name="process_request" value="1">
                                            
                                            <button type="submit" name="action" value="approve" class="btn btn-sm btn-success me-2">Approve</button>
                                            <button type="submit" name="action" value="reject" class="btn btn-sm btn-danger">Reject</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
    
    <?php if ($activeTab === 'events'): ?>
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Club Events</h5>
            <a href="<?php echo BASE_URL; ?>/pages/create_event.php?club_id=<?php echo $clubId; ?>" class="btn btn-sm btn-primary">
                <i class="fas fa-plus-circle me-2"></i> Create Event
            </a>
        </div>
        <div class="card-body">
            <?php if (empty($events)): ?>
                <div class="alert alert-info">
                    <p class="mb-0">No events found for this club.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Event Name</th>
                                <th>Date</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($events as $event): ?>
                                <?php 
                                $statusBadge = 'bg-primary';
                                if ($event['status'] === 'completed') {
                                    $statusBadge = 'bg-success';
                                } elseif ($event['status'] === 'upcoming') {
                                    $statusBadge = 'bg-info text-dark';
                                } elseif ($event['status'] === 'ongoing') {
                                    $statusBadge = 'bg-warning text-dark';
                                } elseif ($event['status'] === 'cancelled') {
                                    $statusBadge = 'bg-danger';
                                }
                                ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($event['event_name']); ?></td>
                                    <td><?php echo formatDateTime($event['event_date']); ?></td>
                                    <td><?php echo htmlspecialchars($event['location'] ?: 'No location'); ?></td>
                                    <td><span class="badge <?php echo $statusBadge; ?>"><?php echo ucfirst($event['status']); ?></span></td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo BASE_URL; ?>/pages/event_details.php?id=<?php echo $event['event_id']; ?>" class="btn btn-sm btn-outline-primary">View</a>
                                            <a href="<?php echo BASE_URL; ?>/pages/edit_event.php?id=<?php echo $event['event_id']; ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php
// Include footer
include __DIR__ . '/../partials/footer.php';
?> 
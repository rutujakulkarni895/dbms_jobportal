<?php
/**
 * Club Details Page
 */

// Include configuration
require_once __DIR__ . '/../config/config.php';

// Check if club ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    setFlashMessage('error', 'Club ID is required.');
    redirect(BASE_URL . '/pages/clubs.php');
}

$clubId = (int)$_GET['id'];

// Get club details
$club = getClubById($clubId);

if (!$club) {
    setFlashMessage('error', 'Club not found.');
    redirect(BASE_URL . '/pages/clubs.php');
}

// Check if user is a member of this club
$isMember = false;
$memberRole = null;
$memberId = null;

if (isLoggedIn()) {
    $userId = getCurrentUserId();
    $conn = getDBConnection();
    
    // Check membership
    $stmt = $conn->prepare("
        SELECT member_id, role
        FROM club_members
        WHERE club_id = ? AND user_id = ?
    ");
    $stmt->bind_param("ii", $clubId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $memberInfo = $result->fetch_assoc();
        $isMember = true;
        $memberRole = $memberInfo['role'];
        $memberId = $memberInfo['member_id'];
    }
    
    // Check pending request
    $stmt = $conn->prepare("
        SELECT req_id, status
        FROM membership_requests
        WHERE club_id = ? AND user_id = ? AND status = 'pending'
    ");
    $stmt->bind_param("ii", $clubId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $hasPendingRequest = ($result->num_rows > 0);
    
    // Process join request
    if (isset($_POST['join_club'])) {
        $result = requestClubMembership($userId, $clubId);
        
        if ($result['success']) {
            setFlashMessage('success', $result['message']);
        } else {
            setFlashMessage('error', $result['message']);
        }
        
        // Redirect to avoid form resubmission
        redirect(BASE_URL . '/pages/club_details.php?id=' . $clubId);
    }
    
    // Process leave club
    if (isset($_POST['leave_club']) && isset($_POST['member_id'])) {
        $memberId = (int)$_POST['member_id'];
        
        // Check if user is trying to leave a club they created
        $stmt = $conn->prepare("
            SELECT cm.member_id, c.created_by, c.club_name, cm.role
            FROM club_members cm
            JOIN clubs c ON cm.club_id = c.club_id
            WHERE cm.member_id = ? AND cm.user_id = ?
        ");
        $stmt->bind_param("ii", $memberId, $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $memberInfo = $result->fetch_assoc();
            
            // Prevent leaving if user is the creator/admin
            if ($memberInfo['created_by'] == $userId && $memberInfo['role'] == 'admin') {
                setFlashMessage('error', 'You cannot leave a club you created. Transfer ownership first or delete the club.');
            } else {
                // Remove the member
                $stmt = $conn->prepare("DELETE FROM club_members WHERE member_id = ? AND user_id = ?");
                $stmt->bind_param("ii", $memberId, $userId);
                
                if ($stmt->execute()) {
                    setFlashMessage('success', 'You have left the club successfully.');
                    $isMember = false;
                    $memberRole = null;
                } else {
                    setFlashMessage('error', 'Failed to leave the club: ' . $conn->error);
                }
            }
        } else {
            setFlashMessage('error', 'Invalid request.');
        }
        
        // Redirect to avoid form resubmission
        redirect(BASE_URL . '/pages/club_details.php?id=' . $clubId);
    }
}

// Get club members
$members = getClubMembers($clubId);

// Get upcoming events
$conn = getDBConnection();
$stmt = $conn->prepare("
    SELECT e.*
    FROM events e
    WHERE e.club_id = ? AND e.status = 'upcoming' AND e.event_date > NOW()
    ORDER BY e.event_date
    LIMIT 5
");
$stmt->bind_param("i", $clubId);
$stmt->execute();
$result = $stmt->get_result();
$upcomingEvents = [];
while ($row = $result->fetch_assoc()) {
    $upcomingEvents[] = $row;
}

// Include header
include __DIR__ . '/../partials/header.php';
?>

<div class="row mb-4">
    <div class="col-md-8">
        <h1><?php echo htmlspecialchars($club['club_name']); ?></h1>
        <p class="lead"><?php echo htmlspecialchars($club['description']); ?></p>
        
        <div class="club-meta text-muted mb-4">
            <div class="row">
                <div class="col-md-4">
                    <p><strong>Created:</strong> <?php echo formatDateTime($club['created_at'], 'M d, Y'); ?></p>
                </div>
                <div class="col-md-4">
                    <p><strong>Members:</strong> <?php echo $club['total_members']; ?></p>
                </div>
                <div class="col-md-4">
                    <p><strong>Upcoming Events:</strong> <?php echo $club['upcoming_events']; ?></p>
                </div>
            </div>
        </div>
        
        <?php if (!isLoggedIn()): ?>
            <div class="alert alert-info">
                <p><i class="fas fa-info-circle me-2"></i> You need to be logged in to join this club.</p>
                <a href="<?php echo BASE_URL; ?>/pages/login.php" class="btn btn-primary">Login</a>
                <a href="<?php echo BASE_URL; ?>/pages/register.php" class="btn btn-outline-primary">Register</a>
            </div>
        <?php elseif ($isMember): ?>
            <div class="alert alert-success">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-0"><i class="fas fa-check-circle me-2"></i> You are a member of this club with <strong><?php echo ucfirst($memberRole); ?></strong> role.</p>
                    </div>
                    
                    <?php if ($club['created_by'] != getCurrentUserId() || $memberRole != 'admin'): ?>
                        <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) . '?id=' . $clubId; ?>" onsubmit="return confirm('Are you sure you want to leave this club?');">
                            <input type="hidden" name="member_id" value="<?php echo $memberId; ?>">
                            <input type="hidden" name="leave_club" value="1">
                            <button type="submit" class="btn btn-outline-danger">Leave Club</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php elseif (isset($hasPendingRequest) && $hasPendingRequest): ?>
            <div class="alert alert-warning">
                <p><i class="fas fa-clock me-2"></i> Your membership request is pending approval.</p>
            </div>
        <?php else: ?>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) . '?id=' . $clubId; ?>">
                <input type="hidden" name="join_club" value="1">
                <button type="submit" class="btn btn-primary">Request to Join Club</button>
            </form>
        <?php endif; ?>
    </div>
    
    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Club Information</h5>
            </div>
            <div class="card-body">
                <p><strong>Created by:</strong> <?php echo htmlspecialchars($club['creator_first_name'] . ' ' . $club['creator_last_name']); ?></p>
                
                <?php if ($isMember && ($memberRole == 'admin' || $memberRole == 'moderator')): ?>
                    <div class="alert alert-info mb-0">
                        <p class="mb-0"><i class="fas fa-info-circle me-2"></i> As a <?php echo $memberRole; ?>, you can manage this club.</p>
                    </div>
                    
                    <div class="d-grid gap-2 mt-3">
                        <a href="<?php echo BASE_URL; ?>/pages/manage_club.php?id=<?php echo $clubId; ?>" class="btn btn-success">Manage Club</a>
                        <a href="<?php echo BASE_URL; ?>/pages/create_event.php?club_id=<?php echo $clubId; ?>" class="btn btn-outline-primary">Create Event</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if ($club['pending_requests'] > 0 && $isMember && ($memberRole == 'admin' || $memberRole == 'moderator')): ?>
            <div class="card mb-4">
                <div class="card-header bg-warning text-dark">
                    <h5 class="mb-0">Pending Requests (<?php echo $club['pending_requests']; ?>)</h5>
                </div>
                <div class="card-body">
                    <p>There are pending membership requests waiting for your approval.</p>
                    <a href="<?php echo BASE_URL; ?>/pages/manage_club.php?id=<?php echo $clubId; ?>&tab=requests" class="btn btn-warning">Review Requests</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Upcoming Events</h5>
                <?php if ($isMember): ?>
                    <a href="<?php echo BASE_URL; ?>/pages/events.php?club_id=<?php echo $clubId; ?>" class="btn btn-sm btn-outline-primary">View All Events</a>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <?php if (empty($upcomingEvents)): ?>
                    <div class="alert alert-info">
                        <p class="mb-0">No upcoming events scheduled.</p>
                    </div>
                <?php else: ?>
                    <div class="list-group">
                        <?php foreach ($upcomingEvents as $event): ?>
                            <a href="<?php echo BASE_URL; ?>/pages/event_details.php?id=<?php echo $event['event_id']; ?>" class="list-group-item list-group-item-action">
                                <div class="d-flex w-100 justify-content-between">
                                    <h5 class="mb-1"><?php echo htmlspecialchars($event['event_name']); ?></h5>
                                    <small><?php echo formatDateTime($event['event_date']); ?></small>
                                </div>
                                <p class="mb-1"><?php echo htmlspecialchars(substr($event['description'], 0, 100)) . (strlen($event['description']) > 100 ? '...' : ''); ?></p>
                                <small class="text-muted"><i class="fas fa-map-marker-alt me-1"></i> <?php echo htmlspecialchars($event['location'] ?: 'No location specified'); ?></small>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if (count($upcomingEvents) >= 5): ?>
                        <div class="text-center mt-3">
                            <a href="<?php echo BASE_URL; ?>/pages/events.php?club_id=<?php echo $clubId; ?>" class="btn btn-sm btn-outline-primary">View More Events</a>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                
                <?php if ($isMember && ($memberRole == 'admin' || $memberRole == 'moderator')): ?>
                    <div class="text-center mt-3">
                        <a href="<?php echo BASE_URL; ?>/pages/create_event.php?club_id=<?php echo $clubId; ?>" class="btn btn-success"><i class="fas fa-plus-circle me-2"></i> Create New Event</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Members (<?php echo count($members); ?>)</h5>
                <?php if ($isMember && ($memberRole == 'admin' || $memberRole == 'moderator')): ?>
                    <a href="<?php echo BASE_URL; ?>/pages/manage_club.php?id=<?php echo $clubId; ?>&tab=members" class="btn btn-sm btn-outline-primary">Manage</a>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <?php if (empty($members)): ?>
                    <div class="alert alert-info">
                        <p class="mb-0">No members yet.</p>
                    </div>
                <?php else: ?>
                    <ul class="list-group">
                        <?php 
                        // Sort members by role (admin first, then moderator, then member)
                        usort($members, function($a, $b) {
                            $roleOrder = ['admin' => 1, 'moderator' => 2, 'member' => 3];
                            return $roleOrder[$a['role']] <=> $roleOrder[$b['role']];
                        });
                        
                        // Limit to 10 members with "View More" button
                        $displayMembers = array_slice($members, 0, 10);
                        
                        foreach ($displayMembers as $member):
                            $badgeClass = '';
                            if ($member['role'] == 'admin') {
                                $badgeClass = 'bg-danger';
                            } elseif ($member['role'] == 'moderator') {
                                $badgeClass = 'bg-warning text-dark';
                            } else {
                                $badgeClass = 'bg-secondary';
                            }
                        ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?>
                                    <span class="badge <?php echo $badgeClass; ?> ms-2"><?php echo ucfirst($member['role']); ?></span>
                                </div>
                                
                                <?php if ($member['user_id'] == $club['created_by']): ?>
                                    <span class="badge bg-info">Creator</span>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    
                    <?php if (count($members) > 10): ?>
                        <div class="text-center mt-3">
                            <a href="<?php echo BASE_URL; ?>/pages/manage_club.php?id=<?php echo $clubId; ?>&tab=members" class="btn btn-sm btn-outline-primary">View All Members</a>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include __DIR__ . '/../partials/footer.php';
?> 
<?php
/**
 * Create Club Page
 */

// Include configuration
require_once __DIR__ . '/../config/config.php';

// Redirect if not logged in
if (!isLoggedIn()) {
    setFlashMessage('error', 'You must be logged in to create a club.');
    redirect(BASE_URL . '/pages/login.php');
}

// Process club creation form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $clubName = cleanInput($_POST['club_name'] ?? '');
    $description = cleanInput($_POST['description'] ?? '');
    
    // Validate form
    $errors = [];
    
    if (empty($clubName)) {
        $errors[] = 'Club name is required';
    }
    
    if (empty($description)) {
        $errors[] = 'Description is required';
    }
    
    // Attempt club creation if no errors
    if (empty($errors)) {
        $result = createClub($clubName, $description, getCurrentUserId());
        
        if ($result['success']) {
            // Set success message
            setFlashMessage('success', 'Club created successfully!');
            
            // Redirect to the new club's details page
            redirect(BASE_URL . '/pages/club_details.php?id=' . $result['club_id']);
        } else {
            $errors[] = $result['message'];
        }
    }
}

// Include header
include __DIR__ . '/../partials/header.php';
?>

<div class="row">
    <div class="col-md-8 offset-md-2">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Create New Club</h5>
            </div>
            <div class="card-body">
                <?php if (isset($errors) && !empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="needs-validation" novalidate>
                    <div class="mb-3">
                        <label for="club_name" class="form-label">Club Name</label>
                        <input type="text" class="form-control" id="club_name" name="club_name" value="<?php echo $clubName ?? ''; ?>" required>
                        <div class="invalid-feedback">Please enter a club name.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="5" required><?php echo $description ?? ''; ?></textarea>
                        <div class="invalid-feedback">Please enter a description for your club.</div>
                        <small class="form-text text-muted">Describe the purpose and activities of your club.</small>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Create Club</button>
                        <a href="<?php echo BASE_URL; ?>/pages/clubs.php" class="btn btn-outline-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="card mt-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">Club Creation Guidelines</h5>
            </div>
            <div class="card-body">
                <ul class="mb-0">
                    <li>Choose a unique name that reflects the club's purpose</li>
                    <li>Provide a detailed description to attract potential members</li>
                    <li>As club creator, you will automatically become its admin</li>
                    <li>Club admins can approve membership requests and create events</li>
                    <li>Consider the club's focus, activities, and goals</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include __DIR__ . '/../partials/footer.php';
?> 
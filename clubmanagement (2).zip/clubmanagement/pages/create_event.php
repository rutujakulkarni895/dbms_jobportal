<?php
/**
 * Create Event Page
 * Allows club admins/moderators to create new events
 */

// Include configuration
require_once __DIR__ . '/../config/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    setFlashMessage('error', 'You must be logged in to create an event.');
    redirect(BASE_URL . '/pages/login.php');
}

$userId = getCurrentUserId();

// Check if club_id is provided
$clubId = null;
if (isset($_GET['club_id']) && !empty($_GET['club_id'])) {
    $clubId = (int)$_GET['club_id'];
    
    // Get club details
    $club = getClubById($clubId);
    
    if (!$club) {
        setFlashMessage('error', 'Club not found.');
        redirect(BASE_URL . '/pages/my_clubs.php');
    }
    
    // Check if user is an admin or moderator of this club
    $conn = getDBConnection();
    $stmt = $conn->prepare("
        SELECT role
        FROM club_members
        WHERE club_id = ? AND user_id = ? AND role IN ('admin', 'moderator')
    ");
    $stmt->bind_param("ii", $clubId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        setFlashMessage('error', 'You do not have permission to create events for this club.');
        redirect(BASE_URL . '/pages/club_details.php?id=' . $clubId);
    }
}

// Get user's clubs where they are admin or moderator
$conn = getDBConnection();
$stmt = $conn->prepare("
    SELECT c.club_id, c.club_name, cm.role
    FROM clubs c
    JOIN club_members cm ON c.club_id = cm.club_id
    WHERE cm.user_id = ? AND cm.role IN ('admin', 'moderator')
    ORDER BY c.club_name
");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$userClubs = [];
while ($row = $result->fetch_assoc()) {
    $userClubs[] = $row;
}

// If user doesn't have any clubs where they can create events
if (empty($userClubs) && !$clubId) {
    setFlashMessage('error', 'You need to be an admin or moderator of at least one club to create events.');
    redirect(BASE_URL . '/pages/my_clubs.php');
}

// Form processing
if (isset($_POST['create_event'])) {
    // Validate and sanitize inputs
    $formClubId = isset($_POST['club_id']) ? (int)$_POST['club_id'] : 0;
    $eventName = cleanInput($_POST['event_name']);
    $description = cleanInput($_POST['description']);
    $location = cleanInput($_POST['location']);
    $eventDate = cleanInput($_POST['event_date']);
    $eventTime = cleanInput($_POST['event_time']);
    
    // Combine date and time
    $eventDateTime = $eventDate . ' ' . $eventTime . ':00';
    
    // Validate inputs
    $errors = [];
    
    if ($formClubId <= 0) {
        $errors[] = 'Please select a club.';
    }
    
    if (empty($eventName)) {
        $errors[] = 'Event name is required.';
    }
    
    if (empty($description)) {
        $errors[] = 'Event description is required.';
    }
    
    if (empty($eventDate) || empty($eventTime)) {
        $errors[] = 'Event date and time are required.';
    } else {
        // Validate date format and ensure it's in the future
        $eventTimestamp = strtotime($eventDateTime);
        $currentTimestamp = time();
        
        if ($eventTimestamp === false) {
            $errors[] = 'Invalid date or time format.';
        } elseif ($eventTimestamp < $currentTimestamp) {
            $errors[] = 'Event date and time must be in the future.';
        }
    }
    
    // If no errors, create the event
    if (empty($errors)) {
        // Verify user has permission to create events for this club
        $stmt = $conn->prepare("
            SELECT role
            FROM club_members
            WHERE club_id = ? AND user_id = ? AND role IN ('admin', 'moderator')
        ");
        $stmt->bind_param("ii", $formClubId, $userId);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows === 0) {
            setFlashMessage('error', 'You do not have permission to create events for this club.');
            redirect(BASE_URL . '/pages/create_event.php');
        }
        
        // Create the event
        $stmt = $conn->prepare("
            INSERT INTO events (club_id, event_name, description, event_date, location, created_by, status)
            VALUES (?, ?, ?, ?, ?, ?, 'upcoming')
        ");
        $stmt->bind_param("issssi", $formClubId, $eventName, $description, $eventDateTime, $location, $userId);
        
        if ($stmt->execute()) {
            $eventId = $conn->insert_id;
            setFlashMessage('success', 'Event created successfully!');
            redirect(BASE_URL . '/pages/event_details.php?id=' . $eventId);
        } else {
            setFlashMessage('error', 'Failed to create event: ' . $conn->error);
        }
    } else {
        // Set error messages
        foreach ($errors as $error) {
            setFlashMessage('error', $error);
        }
    }
}

// Include header
include __DIR__ . '/../partials/header.php';
?>

<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1>Create New Event</h1>
            <p class="lead">Create a new event for your club members.</p>
        </div>
        <div class="col-md-4 text-end">
            <?php if ($clubId): ?>
            <a href="<?php echo BASE_URL; ?>/pages/club_details.php?id=<?php echo $clubId; ?>" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Back to Club
            </a>
            <?php else: ?>
            <a href="<?php echo BASE_URL; ?>/pages/my_clubs.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Back to My Clubs
            </a>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Event Details</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) . ($clubId ? '?club_id=' . $clubId : ''); ?>">
                        <div class="mb-3">
                            <label for="club_id" class="form-label">Club</label>
                            <?php if ($clubId): ?>
                                <input type="hidden" name="club_id" value="<?php echo $clubId; ?>">
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($club['club_name']); ?>" disabled>
                            <?php else: ?>
                                <select class="form-select" id="club_id" name="club_id" required>
                                    <option value="">Select a club</option>
                                    <?php foreach ($userClubs as $userClub): ?>
                                        <option value="<?php echo $userClub['club_id']; ?>"><?php echo htmlspecialchars($userClub['club_name']); ?> (<?php echo ucfirst($userClub['role']); ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mb-3">
                            <label for="event_name" class="form-label">Event Name</label>
                            <input type="text" class="form-control" id="event_name" name="event_name" value="<?php echo isset($_POST['event_name']) ? htmlspecialchars($_POST['event_name']) : ''; ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="4" required><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="event_date" class="form-label">Date</label>
                                <input type="date" class="form-control" id="event_date" name="event_date" value="<?php echo isset($_POST['event_date']) ? htmlspecialchars($_POST['event_date']) : date('Y-m-d', strtotime('+1 day')); ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label for="event_time" class="form-label">Time</label>
                                <input type="time" class="form-control" id="event_time" name="event_time" value="<?php echo isset($_POST['event_time']) ? htmlspecialchars($_POST['event_time']) : '18:00'; ?>" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="location" class="form-label">Location</label>
                            <input type="text" class="form-control" id="location" name="location" value="<?php echo isset($_POST['location']) ? htmlspecialchars($_POST['location']) : ''; ?>" placeholder="Enter venue, address, or online meeting link">
                        </div>
                        
                        <input type="hidden" name="create_event" value="1">
                        <button type="submit" class="btn btn-primary">Create Event</button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Tips for Creating Events</h5>
                </div>
                <div class="card-body">
                    <ul class="mb-0">
                        <li class="mb-2">Choose a clear, descriptive event name that tells members what to expect.</li>
                        <li class="mb-2">Provide complete details in the description including what members should bring or prepare.</li>
                        <li class="mb-2">If it's an online event, include the meeting platform and whether members need to download anything.</li>
                        <li class="mb-2">For in-person events, provide the full address and any special instructions to find the location.</li>
                        <li class="mb-2">Set realistic dates and times, and give members enough notice.</li>
                    </ul>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">After Creating an Event</h5>
                </div>
                <div class="card-body">
                    <p>Once your event is created, you can:</p>
                    <ul class="mb-0">
                        <li class="mb-2">Share the event with your club members</li>
                        <li class="mb-2">Track who's attending</li>
                        <li class="mb-2">Update event details if anything changes</li>
                        <li class="mb-2">Send reminders closer to the event date</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include __DIR__ . '/../partials/footer.php';
?> 
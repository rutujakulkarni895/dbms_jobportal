# Club Management System

A PHP and MySQL-based web application for managing clubs, memberships, and events.

## Features

- User Registration and Authentication
- Club Creation and Management
- Membership Requests and Approvals
- Event Creation and Management
- User Dashboard with Statistics
- Responsive Design

## Requirements

- PHP 7.4 or higher
- MySQL 5.7 or higher
- Apache/Nginx web server
- XAMPP (or similar local development environment)

## Installation

1. Clone or download the repository to your XAMPP htdocs folder
2. Create the database by importing the SQL schema
3. Configure the database connection in includes/database/db_connect.php
4. Access the application through your web browser at http://localhost/clubmanagement

## Project Structure

```
clubmanagement/
├── assets/            # CSS, JavaScript, and images
├── config/            # Configuration files
├── includes/          # Core functionality
│   ├── database/      # Database connection
│   └── functions/     # Helper functions
├── pages/             # Application pages
├── partials/          # Reusable page components
├── index.php          # Main entry point
└── tables sql.sql     # Database schema
```

## Usage

1. Register a new account or log in with existing credentials
2. Browse available clubs or create your own
3. Join clubs by submitting membership requests
4. Participate in club events
5. Manage club members and events as an admin 